# OSINT Bot Discord — v4.0

Bot Discord OSINT containerise, Components V2, zero emoji.

## Configuration — config.json

```json
{
  "token": "TON_TOKEN_BOT_DISCORD",
  "prefix": "-",
  "adminIds": ["TON_ID_DISCORD"],
  "twitchStatusName": "NomDuStreamerTwitch",
  "logChannelId": "ID_SALON_LOGS",
  "botStatus": {
    "type": "STREAMING",
    "text": "NomDuStreamerTwitch",
    "url": "https://www.twitch.tv/NomDuStreamerTwitch"
  }
}
```

| Champ | Description |
|---|---|
| `token` | Token du bot Discord |
| `prefix` | Prefixe des commandes (ex: `-`) |
| `adminIds` | IDs Discord des admins (tableau) |
| `twitchStatusName` | Nom du stream Twitch affiche dans le statut du bot |
| `logChannelId` | ID du salon ou logger les recherches |
| `botStatus.url` | URL Twitch pour le statut streaming |
| `brixhubApiKey` | Clé API BrixHub (préférer la variable `BRIXHUB_API_KEY`) |

La recherche utilise BrixHub (`https://brixhub.net/api/v1/search`). Pour éviter
de stocker la clé dans le fichier de configuration, définissez `BRIXHUB_API_KEY`
dans les variables d’environnement ou les Secrets Replit.

## Lancement

### Docker (recommande)
```bash
docker-compose up -d --build
```

### Node.js
```bash
npm install
npm start
```

## Commandes

| Commande | Acces | Description |
|---|---|---|
| `-help` | Tous | Aide |
| `-panel` | Admin | Envoie le panel OSINT dans le salon |

## Fonctionnement du panel

1. Admin fait `-panel` dans un salon
2. Le panel apparait avec un menu deroulant
3. Selectionner `Instagram` ouvre une modale
4. Entrer un pseudo Instagram public
5. Le bot affiche le rapport complet

Le panel fonctionne apres chaque reboot car les interactions
sont gerees en temps reel par l'event `interactionCreate`.

## Module Instagram — donnees recuperees

- Pseudo, nom complet, biographie, categorie, pronoms
- Abonnes / abonnements / publications
- Taux d'engagement, ratio, tier (micro/macro/mega)
- Liens en bio, email & telephone publics, ville, adresse
- ID Instagram, PK brut, type de compte
- Highlights, IGTV, Reels, comptes similaires
- 6 derniers posts avec stats detaillees
- Export TXT complet

## Logs

Chaque recherche est loggee dans le salon `logChannelId` :
- Operateur (tag + ID)
- Cible
- Heure
- Resume des donnees cles (abonnes, prive, verifie, email, tel, ID)

## Structure

```
osint-bot/
├── config.json
├── docker-compose.yml
├── Dockerfile
├── package.json
└── src/
    ├── index.js
    ├── commands/
    │   ├── help.js
    │   └── panel.js
    ├── events/
    │   ├── ready.js
    │   ├── messageCreate.js
    │   └── interactionCreate.js
    ├── modules/
    │   ├── panel.js
    │   └── instagram.js
    └── utils/
        ├── builders.js
        ├── instagramScraper.js
        └── logger.js
```

'use strict';
const { buildPanel } = require('../utils/builders');
module.exports = {
  name: 'panel',
  adminOnly: true,
  async execute(message, args, client) {
    await message.delete().catch(() => {});
    await message.channel.send(buildPanel(client.config));
  },
};

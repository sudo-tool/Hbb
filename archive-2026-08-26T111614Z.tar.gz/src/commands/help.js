'use strict';
const { buildHelp } = require('../utils/builders');
module.exports = {
  name: 'help',
  adminOnly: false,
  async execute(message, args, client) {
    const isAdmin = client.config.adminIds.includes(message.author.id);
    await message.reply(buildHelp(client.config.prefix, isAdmin));
  },
};

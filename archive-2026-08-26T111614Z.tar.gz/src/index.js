'use strict';

const fs   = require('fs');
const path = require('path');
const config = require('../config.json');

const discordEnabled  = !!(config.token  && config.token  !== 'TON_TOKEN_DISCORD_ICI');
const telegramEnabled = !!(config.telegram?.token && config.telegram.token !== 'TON_TOKEN_TELEGRAM_ICI' && config.telegram.enabled !== false);

console.log('[CONFIG] Discord  :', discordEnabled  ? 'activé' : 'désactivé');
console.log('[CONFIG] Telegram :', telegramEnabled ? 'activé' : 'désactivé');

if (!discordEnabled && !telegramEnabled) {
  console.error('[FATAL] Aucun token configuré (Discord ou Telegram)');
  process.exit(1);
}

// ── Telegram ──────────────────────────────────────────────────────────────────
if (telegramEnabled) {
  const { startTelegramBot } = require('./telegramBot');
  startTelegramBot(config);
}

// ── Discord ───────────────────────────────────────────────────────────────────
if (discordEnabled) {
  const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildPresences,
    ],
    partials: [Partials.Message, Partials.Channel],
  });

  client.commands = new Collection();
  client.config   = config;

  const cmdsPath = path.join(__dirname, 'commands');
  for (const f of fs.readdirSync(cmdsPath).filter(f => f.endsWith('.js'))) {
    const cmd = require(path.join(cmdsPath, f));
    client.commands.set(cmd.name, cmd);
    console.log('[CMD]', cmd.name);
  }

  const evtsPath = path.join(__dirname, 'events');
  for (const f of fs.readdirSync(evtsPath).filter(f => f.endsWith('.js'))) {
    const evt = require(path.join(evtsPath, f));
    evt.once
      ? client.once(evt.name, (...a) => evt.execute(...a, client))
      : client.on(evt.name,   (...a) => evt.execute(...a, client));
    console.log('[EVT]', evt.name);
  }

  client.login(config.token).catch(err => {
    console.error('[FATAL Discord]', err.message);
    if (!telegramEnabled) process.exit(1);
  });
}

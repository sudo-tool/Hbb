'use strict';

const fs   = require('fs');
const path = require('path');
const zlib = require('zlib');
const { AttachmentBuilder, MessageFlags, ContainerBuilder, TextDisplayBuilder, FileBuilder } = require('discord.js');
const { convert }    = require('./exporters');
const { buildError, e } = require('./builders');

const DATA_DIR = path.join(__dirname, '../../data');

async function generate(interaction, key, mod, format, doZip) {
  const fp = path.join(DATA_DIR, mod + '_' + key + '.json');
  let data;
  try { data = JSON.parse(fs.readFileSync(fp, 'utf8')); }
  catch { return interaction.editReply(buildError('Pas de donnees', 'Lance d\'abord une recherche.')); }

  const { content, ext } = convert(mod, format, data);
  let   buffer           = Buffer.from(content, 'utf8');
  const basename         = 'osint_' + mod + '_' + key + '_' + Date.now();
  const filename         = doZip ? basename + '.' + ext + '.gz' : basename + '.' + ext;
  if (doZip) buffer      = zlib.gzipSync(buffer);

  const att      = new AttachmentBuilder(buffer, { name: filename });
  const fileComp = new FileBuilder().setURL('attachment://' + filename);
  const eDl      = e('download');
  const sizeKb   = (buffer.length / 1024).toFixed(1);

  const colors = { gh: 0x24292E, ip: 0x00D4FF, search: 0xE1306C, tool: 0x5865F2 };
  const color  = colors[mod] ?? 0x5865F2;

  // Container avec FileBuilder pour le fil éphémère
  const ctr = new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      (eDl ? eDl + '  ' : '') +
      '**Rapport `' + mod.toUpperCase() + '` — `' + key + '`**\n' +
      '> Format : `.' + ext + '`' + (doZip ? '  `.gz`' : '') + '\n' +
      '> Taille : `' + sizeKb + ' KB`'
    ))
    .addFileComponents(fileComp);

  await interaction.editReply({
    components: [ctr],
    files:      [att],
    flags:      MessageFlags.IsComponentsV2,
  });

  // DM — mention dans le TextDisplay (pas de content séparé avec IsComponentsV2)
  try {
    const user  = interaction.user;
    const dm    = await user.createDM();

    // Nouveau buffer identique (les buffers ne peuvent pas être réutilisés)
    const att2  = new AttachmentBuilder(buffer, { name: filename });
    const ctrDM = new ContainerBuilder().setAccentColor(color)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        '<@' + user.id + '>\n' +
        (eDl ? eDl + '  ' : '') +
        '**Rapport `' + mod.toUpperCase() + '` — `' + key + '`**\n' +
        '> Format : `.' + ext + '`' + (doZip ? '  `.gz`' : '') + '\n' +
        '> Taille : `' + sizeKb + ' KB`'
      ))
      .addFileComponents(new FileBuilder().setURL('attachment://' + filename));

    await dm.send({
      components: [ctrDM],
      files:      [att2],
      flags:      MessageFlags.IsComponentsV2,
    });
  } catch (err) {
    console.warn('[DM] Impossible d\'envoyer :', err.message);
  }
}

function save(key, mod, data) {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(
      path.join(DATA_DIR, mod + '_' + key + '.json'),
      JSON.stringify({ ...data, cachedAt: Date.now() }, null, 2)
    );
  } catch (_) {}
}

module.exports = { generate, save };

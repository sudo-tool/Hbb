'use strict';

/**
 * builders.js v5.7
 *
 * BONNE structure Components V2 :
 *   container.addActionRowComponents(new ActionRowBuilder()...)
 *   => ActionRow EST DANS le container
 *
 * Tout est dans un seul ContainerBuilder.
 * components: [container]  + flags: IsComponentsV2
 */

const {
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SectionBuilder,
  ThumbnailBuilder, ActionRowBuilder, StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle,
  SeparatorSpacingSize, MessageFlags, FileBuilder, AttachmentBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder,
} = require('discord.js');

const { e, emojiObj } = require('./emojiManager');

const txt  = c  => new TextDisplayBuilder().setContent(c);
const sep  = () => new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true);
const sepL = () => new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Large).setDivider(false);

const C = {
  accent : 0x5865F2,
  gh     : 0x24292E,
  ip     : 0x00D4FF,
  error  : 0xED4245,
  search : 0xE1306C,
  dl     : 0x57F287,
  info   : 0xFEE75C,
  tool   : 0x2B2D31,
};

function fmt(n) {
  if (n == null) return '—';
  const num = Number(n);
  if (isNaN(num)) return '—';
  if (num >= 1_000_000) return (num/1_000_000).toFixed(1)+'M';
  if (num >= 1_000)     return (num/1_000).toFixed(1)+'K';
  return String(num);
}

function _cv2(container) {
  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function _opt(label, desc, value, ek) {
  const opt = new StringSelectMenuOptionBuilder().setLabel(label).setDescription(desc).setValue(value);
  const obj = ek ? emojiObj(ek) : null;
  if (obj) opt.setEmoji(obj);
  return opt;
}

// ─────────────────────────────────────────────────────────────────────────────
// Error
// ─────────────────────────────────────────────────────────────────────────────
function buildError(title, desc) {
  const c = new ContainerBuilder().setAccentColor(C.error)
    .addTextDisplayComponents(txt('**' + title + '**'))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(desc));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Panel
// ─────────────────────────────────────────────────────────────────────────────
function buildPanel(config) {
  const p   = config.panel ?? {};
  const frE = e('france');
  const dE  = e('discord');
  const tE  = e('telegram');

  const c = new ContainerBuilder().setAccentColor(C.accent);

  c.addTextDisplayComponents(txt('# ' + (p.botName||'OSINT Bot') + (frE?' '+frE:'')));

  const links = [];
  if (p.discordLink?.trim())  links.push((dE?dE+' ':'')+'**Discord** — ['+(p.discordName||'Rejoindre')+']('+p.discordLink+')');
  if (p.telegramLink?.trim()) links.push((tE?tE+' ':'')+'**Telegram** — ['+(p.telegramName||'Canal')+']('+p.telegramLink+')');
  if (links.length) {
    c.addSeparatorComponents(sep());
    c.addTextDisplayComponents(txt(links.join('\n')));
  }

  // Bannière plein écran au milieu
  if (p.bannerUrl?.trim()) {
    c.addSeparatorComponents(sep());
    c.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(p.bannerUrl.trim())
      )
    );
  }

  c.addSeparatorComponents(sepL());

  // Menu déroulant DANS le container
  const menu = new StringSelectMenuBuilder()
    .setCustomId('tools_select')
    .setPlaceholder('Selectionner un outil...')
    .addOptions(
      _opt('GitHub',        'Profil, repos, emails OSINT',        'github',         'github'),
      _opt('Analyser IP',   'Geoloc, ASN, ISP, proxy/VPN/Tor',    'analyze-ip',     'ip'),
      _opt('Analyser Hash', 'MD5, SHA1, NTLM, bcrypt...',          'analyze-hash',   'hash'),
      _opt('Telephone',     'Pays, type, operateur',               'analyze-phone',  'phone'),
      _opt('GPS',           'Convertit des coordonnees',           'analyze-gps',    'maison'),
      _opt('Invitation',    'Discord ou Telegram',                 'analyze-invite', 'discord'),
      _opt('Plaque FR',     'Format SIV (AB-123-CD)',               'analyze-plate',  'voiture'),
      _opt('User-Agent',    'Navigateur, OS, device',              'analyze-ua',     'useragent'),
      _opt('DNS',           'A, MX, NS, TXT, AAAA',               'analyze-dns',    'dns'),
    );

  c.addActionRowComponents(new ActionRowBuilder().addComponents(menu));

  // Boutons DANS le container
  const searchBtn = new ButtonBuilder().setCustomId('search_open').setLabel('Searcher').setStyle(ButtonStyle.Primary);
  const sObj = emojiObj('search'); if (sObj) searchBtn.setEmoji(sObj);
  const infoBtn  = new ButtonBuilder().setCustomId('panel_info').setLabel('Info').setStyle(ButtonStyle.Secondary);

  c.addActionRowComponents(new ActionRowBuilder().addComponents(searchBtn, infoBtn));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Info
// ─────────────────────────────────────────────────────────────────────────────
function buildInfo(wsMs, apiMs) {
  const frE = e('france');
  const c = new ContainerBuilder().setAccentColor(C.info)
    .addTextDisplayComponents(txt(
      '**A propos**\n\n'+
      '> **Createur**  [Alzheimer](https://guns.lol/alzheimer)\n'+
      '> **Origine**   France '+(frE||'')+'\n'+
      '> **Version**   v5.7'
    ))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(
      '**Latences**\n\n'+
      '> **Discord WS**  `'+(wsMs!=null?wsMs+'ms':'—')+'`\n'+
      '> **API OSINT**   `'+(apiMs!=null?apiMs+'ms':'—')+'`'
    ));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Loading
// ─────────────────────────────────────────────────────────────────────────────
function buildLoading(target, ck) {
  const lE = e('loading');
  const c = new ContainerBuilder().setAccentColor(C[ck]??C.accent)
    .addTextDisplayComponents(txt((lE?lE+'  ':'')+'**Recherche...**\n> `'+target+'`'));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Search type picker
// ─────────────────────────────────────────────────────────────────────────────
function buildSearchTypePicker() {
  const sE = e('search');
  const nBtn = new ButtonBuilder().setCustomId('search_run_normal').setLabel('Recherche normale').setStyle(ButtonStyle.Primary);
  const sObj = emojiObj('search'); if (sObj) nBtn.setEmoji(sObj);
  const dBtn = new ButtonBuilder().setCustomId('search_run_deep').setLabel('Approfondie').setStyle(ButtonStyle.Danger);
  const dObj = emojiObj('sniper'); if (dObj) dBtn.setEmoji(dObj);

  const c = new ContainerBuilder().setAccentColor(C.search)
    .addTextDisplayComponents(txt((sE?sE+'  ':'')+'**Searcher** — Choisir le type :'))
    .addSeparatorComponents(sep())
    .addActionRowComponents(new ActionRowBuilder().addComponents(nBtn, dBtn));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Search result — 1 résultat/page, max 25 pages
// ─────────────────────────────────────────────────────────────────────────────
function buildSearchPage(query, deep, results, page, total) {
  const maxPage = Math.min(25, results.length);
  const res     = results[page - 1];

  const eLoad  = e('loading');
  const eSniper= e('sniper');
  const eSearch= e('search');
  const eEmail = e('email');
  const ePhone = e('phone');
  const eIp    = e('ip');
  const eMdp   = e('mdp');
  const eFl    = e('fleche');
  const eMaison= e('maison');
  const eOui   = e('oui');
  const eNon   = e('non');

  const hE    = deep?(eSniper||''):(eSearch||'');
  const color = deep ? C.search : C.accent;

  const c = new ContainerBuilder().setAccentColor(color);

  c.addTextDisplayComponents(txt(
    (hE?hE+'  ':'')+
    '**'+(deep?'Approfondie':'Recherche')+'** — `'+query+'`\n'+
    '> **'+total+'** resultat'+(total>1?'s':'')+
    '  ·  Page **'+page+'/'+maxPage+'**'
  ));

  if (!res) {
    c.addSeparatorComponents(sep())
     .addTextDisplayComponents(txt((eNon?eNon+' ':'')+'Aucun resultat.'));
  } else {
    c.addSeparatorComponents(sep());

    const lines = [];
    if (res.source) lines.push('> '+(eSearch?eSearch+' ':'')+'**Source**   `'+res.source+'`');
    if (res.shard)  lines.push('> **Shard**    `'+res.shard+'`');
    if (lines.length) { c.addTextDisplayComponents(txt(lines.join('\n'))); lines.length=0; }

    const id = res.identity ?? {};
    const idL = [];
    if (id.email)    idL.push((eEmail?eEmail+' ':'')+'**Email**      `'+id.email+'`');
    if (id.username) idL.push((eFl?eFl+' ':'')     +'**Pseudo**     `'+id.username+'`');
    if (id.name)     idL.push('**Nom**        '+id.name);
    if (id.phone)    idL.push((ePhone?ePhone+' ':'')+'**Telephone**  `'+id.phone+'`');
    if (id.ip)       idL.push((eIp?eIp+' ':'')     +'**IP**         `'+id.ip+'`');
    if (id.address)  idL.push((eMaison?eMaison+' ':'')+'**Adresse**   '+id.address);
    for (const [k,v] of Object.entries(id)) {
      if (['email','username','name','phone','ip','address'].includes(k)) continue;
      if (v) idL.push('**'+k+'**  `'+String(v).slice(0,80)+'`');
    }
    if (idL.length) { c.addSeparatorComponents(sep()); c.addTextDisplayComponents(txt(idL.join('\n'))); }

    const cr = res.credentials ?? {};
    const crL = [];
    if (cr.password)     crL.push((eMdp?eMdp+' ':'')+'**Password**   `'+cr.password+'`');
    if (cr.hash)         crL.push((eMdp?eMdp+' ':'')+'**Hash**       `'+cr.hash+'`');
    if (cr.passwordHint) crL.push('**Hint**       '+cr.passwordHint);
    for (const [k,v] of Object.entries(cr)) {
      if (['password','hash','passwordHint'].includes(k)) continue;
      if (v) crL.push('**'+k+'**  `'+String(v).slice(0,80)+'`');
    }
    if (crL.length) { c.addSeparatorComponents(sep()); c.addTextDisplayComponents(txt(crL.join('\n'))); }

    const skip = new Set(['source','shard','identity','credentials','preview','raw','_id']);
    const freeL = [];
    for (const [k,v] of Object.entries(res)) {
      if (skip.has(k)||v==null) continue;
      if (typeof v==='object') freeL.push('**'+k+'**\n```json\n'+JSON.stringify(v,null,2).slice(0,200)+'\n```');
      else freeL.push('**'+k+'**  `'+String(v).slice(0,100)+'`');
    }
    if (freeL.length) { c.addSeparatorComponents(sep()); c.addTextDisplayComponents(txt(freeL.join('\n'))); }
  }

  c.addSeparatorComponents(sep())
   .addTextDisplayComponents(txt('-# <t:'+Math.floor(Date.now()/1000)+':R>'));

  // Boutons pagination + télécharger — DANS le container
  const dlBtn = new ButtonBuilder()
    .setCustomId('sr_dl_'+page+'_'+encodeURIComponent(query).slice(0,60))
    .setLabel('Telecharger').setStyle(ButtonStyle.Secondary);
  const dlObj = emojiObj('download'); if (dlObj) dlBtn.setEmoji(dlObj);

  // Un seul bouton : télécharger
  c.addActionRowComponents(new ActionRowBuilder().addComponents(dlBtn));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Deep limit
// ─────────────────────────────────────────────────────────────────────────────
function buildDeepLimitReached(hoursLeft, limit) {
  const eN = e('non');
  const c = new ContainerBuilder().setAccentColor(C.error)
    .addTextDisplayComponents(txt(
      (eN?eN+'  ':'')+'**Limite atteinte**\n\n'+
      '> Tes **'+limit+' recherches approfondies** sont épuisées.\n'+
      '> Reessaie dans **'+hoursLeft+'h**.'
    ));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// GitHub result
// ─────────────────────────────────────────────────────────────────────────────
function buildGithubResult(data) {
  const ghE = e('github'), eNon = e('non'), eEm = e('email');
  const type = data.accountType==='Organization'?'Organisation':'Utilisateur';

  const section = new SectionBuilder()
    .addTextDisplayComponents(txt(
      (ghE?ghE+'  ':'')+'**@'+data.username+'**'+(data.siteAdmin?' · Admin':'')+'\n'+
      (data.name?data.name+'  ·  ':'')+type+(data.location?'  ·  '+data.location:'')
    ))
    .setThumbnailAccessory(new ThumbnailBuilder().setURL(data.avatarUrl||'https://cdn.discordapp.com/embed/avatars/0.png'));

  const c = new ContainerBuilder().setAccentColor(C.gh)
    .addSectionComponents(section)
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(
      '**Repos** `'+data.publicRepos+'`  **Stars** `'+fmt(data.totalStars)+'`  **Followers** `'+fmt(data.followers)+'`'
    ))
    .addSeparatorComponents(sep());

  const emails = data.emails ?? [];
  if (emails.length) {
    c.addTextDisplayComponents(txt('**Emails OSINT**\n'+emails.map(x=>(eEm?eEm+' ':'')+'`'+x+'`').join('\n')))
     .addSeparatorComponents(sep());
  } else {
    c.addTextDisplayComponents(txt((eNon?eNon+' ':'')+'Aucun email reel trouve'))
     .addSeparatorComponents(sep());
  }

  if (data.bio) {
    c.addTextDisplayComponents(txt('```\n'+data.bio.slice(0,150)+'\n```')).addSeparatorComponents(sep());
  }

  c.addTextDisplayComponents(txt('-# <t:'+Math.floor(Date.now()/1000)+':R>'));

  // Boutons DANS le container
  c.addActionRowComponents(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('gh_refresh_'+data.username).setLabel('Rafraichir').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('gh_more_'+data.username).setLabel('Repos & Details').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setURL(data.htmlUrl).setLabel('GitHub').setStyle(ButtonStyle.Link),
    new ButtonBuilder().setCustomId('gh_dl_'+data.username).setLabel('Telecharger').setStyle(ButtonStyle.Secondary),
  ));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// GitHub details
// ─────────────────────────────────────────────────────────────────────────────
function buildGithubDetails(data) {
  const c = new ContainerBuilder().setAccentColor(C.gh)
    .addTextDisplayComponents(txt('**@'+data.username+' — Details**'))
    .addSeparatorComponents(sep());

  const intel=[];
  if (data.githubId)         intel.push('**ID**        `'+data.githubId+'`');
  if (data.blog)             intel.push('**Site**      '+data.blog);
  if (data.twitterUser)      intel.push('**Twitter**   @'+data.twitterUser);
  if (data.topLangs?.length) intel.push('**Langages**  '+data.topLangs.join(', '));
  if (data.company)          intel.push('**Entreprise** '+data.company);
  if (data.createdAt)        intel.push('**Cree le**   <t:'+Math.floor(new Date(data.createdAt).getTime()/1000)+':d>');
  if (intel.length) c.addTextDisplayComponents(txt(intel.join('\n'))).addSeparatorComponents(sep());

  if (data.orgs?.length) {
    c.addTextDisplayComponents(txt('**Orgs**\n'+data.orgs.map(o=>'['+o.name+']('+o.url+')').join('  ·  ')))
     .addSeparatorComponents(sep());
  }
  if (data.commitSamples?.length) {
    const lines = data.commitSamples.slice(0,3).map(cm=>
      '`'+cm.sha+'` '+cm.msg.slice(0,50)+(cm.email&&!cm.email.includes('noreply')?'\n> `'+cm.email+'`':'')
    ).join('\n');
    c.addTextDisplayComponents(txt('**Commits**\n'+lines)).addSeparatorComponents(sep());
  }
  if (data.followers5?.length||data.following5?.length) {
    const parts=[];
    if (data.followers5?.length) parts.push('**Followers** '+data.followers5.map(u=>'`'+u+'`').join(' '));
    if (data.following5?.length) parts.push('**Following** '+data.following5.map(u=>'`'+u+'`').join(' '));
    c.addTextDisplayComponents(txt(parts.join('\n'))).addSeparatorComponents(sep());
  }

  // Boutons repos DANS le container
  const repos=(data.topRepos||[]).slice(0,5);
  if (repos.length) {
    const repoRow=new ActionRowBuilder();
    for (const r of repos) {
      const label=(r.name.length>16?r.name.slice(0,15)+'…':r.name)+(r.stars?' ★'+fmt(r.stars):'');
      repoRow.addComponents(new ButtonBuilder().setURL(r.url).setLabel(label).setStyle(ButtonStyle.Link));
    }
    c.addActionRowComponents(repoRow);
  }

  c.addActionRowComponents(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('gh_refresh_'+data.username).setLabel('Retour').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('gh_dl_'+data.username).setLabel('Telecharger').setStyle(ButtonStyle.Primary),
  ));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// IP result
// ─────────────────────────────────────────────────────────────────────────────
function buildIPResult(data) {
  const ipE = e('ip');
  const threats=[];
  if (data.isProxy)  threats.push('Proxy');
  if (data.isVPN)    threats.push('VPN/Hosting');
  if (data.isTor)    threats.push('Tor');
  if (data.isMobile) threats.push('Mobile');

  const flag=(data.countryCode&&data.countryCode!=='—')
    ?String.fromCodePoint(...[...data.countryCode.toUpperCase()].map(ch=>0x1F1E6+ch.charCodeAt(0)-65)):'';

  const c = new ContainerBuilder().setAccentColor(C.ip)
    .addTextDisplayComponents(txt(
      (ipE?ipE+'  ':'')+'**'+data.ip+'**'+
      (threats.length?'  ·  '+threats.join('  ·  '):'')+'\n'+
      flag+(flag?'  ':'')+data.city+(data.city!=='—'&&data.country!=='—'?',  ':'')+data.country
    ))
    .addSeparatorComponents(sep());

  const geo=[];
  if(data.region!=='—')     geo.push('**Region**      '+data.region);
  if(data.postalCode!=='—') geo.push('**Code postal** '+data.postalCode);
  if(data.timezone!=='—')   geo.push('**Timezone**    '+data.timezone);
  if(data.lat&&data.lon)    geo.push('**Coords**      `'+data.lat+', '+data.lon+'`');
  if(geo.length) c.addTextDisplayComponents(txt(geo.join('\n'))).addSeparatorComponents(sep());

  const net=[];
  if(data.isp!=='—')                      net.push('**ISP**      '+data.isp);
  if(data.org!=='—'&&data.org!==data.isp) net.push('**Org**      '+data.org);
  if(data.asn!=='—')                      net.push('**ASN**      `'+data.asn+'`');
  if(data.asnName!=='—')                  net.push('**AS Name**  '+data.asnName);
  if(data.prefix!=='—')                   net.push('**Prefix**   `'+data.prefix+'`');
  if(net.length) c.addTextDisplayComponents(txt(net.join('\n'))).addSeparatorComponents(sep());

  if(data.reverseDns!=='—')   c.addTextDisplayComponents(txt('**rDNS**   `'+data.reverseDns+'`')).addSeparatorComponents(sep());
  if(data.abuseContact!=='—') c.addTextDisplayComponents(txt('**Abuse**  `'+data.abuseContact+'`')).addSeparatorComponents(sep());

  c.addTextDisplayComponents(txt('-# <t:'+Math.floor(Date.now()/1000)+':R>'));

  const key=data.ip.replace(/[:.]/g,'_');
  c.addActionRowComponents(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ip_refresh_'+key).setLabel('Rafraichir').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setURL('https://www.shodan.io/host/'+data.ip).setLabel('Shodan').setStyle(ButtonStyle.Link),
    new ButtonBuilder().setURL('https://www.abuseipdb.com/check/'+data.ip).setLabel('AbuseIPDB').setStyle(ButtonStyle.Link),
    new ButtonBuilder().setCustomId('ip_dl_'+key).setLabel('Telecharger').setStyle(ButtonStyle.Secondary),
  ));

  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Export — format picker
// ─────────────────────────────────────────────────────────────────────────────
function buildExportFormatPicker(key, mod) {
  const color=mod==='gh'?C.gh:mod==='ip'?C.ip:mod==='search'?C.search:mod==='tool'?C.tool:C.accent;
  const eDl=e('download');
  const mkBtn=(fmt,ek)=>{
    const b=new ButtonBuilder().setCustomId(mod+'_fmt_'+fmt+'_'+key).setLabel('.'+fmt).setStyle(ButtonStyle.Secondary);
    const obj=ek?emojiObj(ek):null; if(obj) b.setEmoji(obj);
    return b;
  };
  const c = new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(txt((eDl?eDl+'  ':'')+'**Telecharger — `'+key+'`**\n> Format :'))
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      mkBtn('json','download'), mkBtn('txt','fichier_txt'), mkBtn('sql','fichier_sql'),
      mkBtn('csv','fichier_csv'), mkBtn('xml','fichier_xml'),
    ));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Export — zip picker
// ─────────────────────────────────────────────────────────────────────────────
function buildExportZipPicker(key, mod, format) {
  const color=mod==='gh'?C.gh:mod==='ip'?C.ip:mod==='search'?C.search:mod==='tool'?C.tool:C.accent;
  const yB=new ButtonBuilder().setCustomId(mod+'_zip_yes_'+format+'_'+key).setLabel('Oui — .gz').setStyle(ButtonStyle.Primary);
  const nB=new ButtonBuilder().setCustomId(mod+'_zip_no_'+format+'_'+key).setLabel('Non').setStyle(ButtonStyle.Secondary);
  const zO=emojiObj('fichier_zip'); if(zO) yB.setEmoji(zO);
  const nO=emojiObj('non');         if(nO) nB.setEmoji(nO);
  const c = new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(txt('**Format `.'+format+'`** — Compresser en `.gz` ?'))
    .addActionRowComponents(new ActionRowBuilder().addComponents(yB, nB));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Export generating
// ─────────────────────────────────────────────────────────────────────────────
function buildExportGenerating(key) {
  const lE=e('loading'), dE=e('download');
  const c = new ContainerBuilder().setAccentColor(C.dl)
    .addTextDisplayComponents(txt((lE?lE+'  ':dE?dE+'  ':'')+'**Generation...**\n> `'+key+'`'));
  return _cv2(c);
}

// ─────────────────────────────────────────────────────────────────────────────
// Export file — FileBuilder dans container
// ─────────────────────────────────────────────────────────────────────────────
function buildExportFile(key, mod, filename, buffer, ext, isGz) {
  const color=mod==='gh'?C.gh:mod==='ip'?C.ip:C.accent;
  const eDl=e('download');
  const sizeKb=(buffer.length/1024).toFixed(1);
  const att=new AttachmentBuilder(buffer,{name:filename});
  const fc=new FileBuilder().setURL('attachment://'+filename);
  const c=new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(txt(
      (eDl?eDl+'  ':'')+'**Rapport `'+mod.toUpperCase()+'` — `'+key+'`**\n'+
      '> Format : `.'+ext+'`'+(isGz?'  `.gz`':'')+'\n'+
      '> Taille : `'+sizeKb+' KB`'
    ))
    .addFileComponents(fc);
  return { components:[c], files:[att], flags:MessageFlags.IsComponentsV2 };
}

// ─────────────────────────────────────────────────────────────────────────────
// Export DM
// ─────────────────────────────────────────────────────────────────────────────
function buildExportDM(key, mod, filename, buffer, ext, isGz) {
  const eDl=e('download');
  const sizeKb=(buffer.length/1024).toFixed(1);
  const att=new AttachmentBuilder(buffer,{name:filename});
  const c=new ContainerBuilder().setAccentColor(C.dl)
    .addTextDisplayComponents(txt(
      (eDl?eDl+'  ':'')+'**DM — `'+key+'`**\n'+
      '> `.'+ext+'`'+(isGz?' `.gz`':'')+' · `'+sizeKb+' KB`'
    ));
  return { msg:{components:[c],files:[att],flags:MessageFlags.IsComponentsV2} };
}

// ─────────────────────────────────────────────────────────────────────────────
// Help
// ─────────────────────────────────────────────────────────────────────────────
function buildHelp(prefix, isAdmin) {
  const frE=e('france'), sE=e('search'), snE=e('sniper');
  const c=new ContainerBuilder().setAccentColor(C.accent)
    .addTextDisplayComponents(txt('# Bot OSINT '+(frE||'')+'\n> [Alzheimer](https://guns.lol/alzheimer) — France '+(frE||'')))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(
      '**Commandes**\n\n'+
      '`'+prefix+'help`  —  Ce message\n'+
      (isAdmin?'`'+prefix+'panel`  —  Envoie le panel\n':'')
    ))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(
      '**Outils (menu)**\n\n'+
      '`GitHub`  `IP`  `Hash`  `Telephone`  `GPS`\n'+
      '`Invitation`  `Plaque FR`  `User-Agent`  `DNS`'
    ))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(
      '**Recherche**\n\n'+
      (sE?sE+' ':'')+'`Normale`  —  Standard\n'+
      (snE?snE+' ':'')+'`Approfondie`  —  Deep (**2/24h**)\n'+
      '> 1 resultat/page — max 25 pages'
    ))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt('-# OSINT Bot v5.7'));
  return _cv2(c);
}

module.exports = {
  e, emojiObj, fmt,
  buildError, buildPanel, buildInfo, buildLoading,
  buildSearchTypePicker, buildSearchPage, buildDeepLimitReached,
  buildGithubResult, buildGithubDetails,
  buildIPResult,
  buildExportFormatPicker, buildExportZipPicker, buildExportGenerating,
  buildExportFile, buildExportDM,
  buildHelp,
};/* ── Search result — 1 résultat/page, max 25 ──────────────────────────────── */

// Map complète champ → { emojiKey, label }
// Détection auto des valeurs par regex
function detectFieldType(key, val) {
  const s = String(val).trim();
  const k = key.toLowerCase();
  // Tel : commence par +, 0, ou 00 suivi de chiffres
  if (/^(\+|00)?[0-9][0-9 \-\.]{6,20}$/.test(s.replace(/[\s\-\.]/g,''))) {
    if (/^(\+33|0033|0[67])[0-9]{8}$/.test(s.replace(/[\s\-\.]/g,'')) || /^\+[1-9][0-9]{6,14}$/.test(s.replace(/[\s]/g,''))) {
      return 'phone';
    }
  }
  // IP
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(s) || /^[0-9a-fA-F:]{7,39}$/.test(s)) return 'ip';
  // Email
  if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s)) return 'email';
  // Plaque FR (AB-123-CD ou AA 123 AA)
  if (/^[A-Z]{2}[-\s]?[0-9]{3}[-\s]?[A-Z]{2}$/i.test(s)) return 'voiture';
  // Hash MD5/SHA
  if (/^[0-9a-f]{32}$/i.test(s)) return 'hash';
  if (/^[0-9a-f]{40}$/i.test(s)) return 'hash';
  if (/^[0-9a-f]{64}$/i.test(s)) return 'hash';
  // IBAN
  if (/^[A-Z]{2}[0-9]{2}[A-Z0-9]{4,30}$/.test(s.replace(/\s/g,''))) return 'iban';
  return null;
}

const FIELD_MAP = {
  // Email
  email:            { k: 'email',      l: 'Email'         },
  mail:             { k: 'email',      l: 'Email'         },
  email_address:    { k: 'email',      l: 'Email'         },
  // Nom / Prénom
  nom:              { k: 'nom',        l: 'Nom'           },
  name:             { k: 'nom',        l: 'Nom'           },
  last_name:        { k: 'nom',        l: 'Nom'           },
  surname:          { k: 'nom',        l: 'Nom'           },
  prenom:           { k: 'prenom',     l: 'Prénom'        },
  first_name:       { k: 'prenom',     l: 'Prénom'        },
  full_name:        { k: 'nom',        l: 'Nom complet'   },
  // Civilité
  civilite:         { k: 'civilite',   l: 'Civilité'      },
  civility:         { k: 'civilite',   l: 'Civilité'      },
  gender:           { k: 'civilite',   l: 'Genre'         },
  // Téléphone
  phone:            { k: 'phone',      l: 'Téléphone'     },
  telephone:        { k: 'phone',      l: 'Téléphone'     },
  phone_number:     { k: 'phone',      l: 'Téléphone'     },
  mobile:           { k: 'phone',      l: 'Mobile'        },
  // Adresse
  adresse:          { k: 'adresse',    l: 'Adresse'       },
  address:          { k: 'adresse',    l: 'Adresse'       },
  street:           { k: 'adresse',    l: 'Rue'           },
  // Ville
  ville:            { k: 'ville',      l: 'Ville'         },
  city:             { k: 'ville',      l: 'Ville'         },
  // Code postal
  zip:              { k: 'code_postal', l: 'Code postal'  },
  postal_code:      { k: 'code_postal', l: 'Code postal'  },
  code_postal:      { k: 'code_postal', l: 'Code postal'  },
  // Naissance
  birthday:         { k: 'birthday',   l: 'Naissance'     },
  birth_date:       { k: 'birthday',   l: 'Naissance'     },
  date_naissance:   { k: 'naissance',  l: 'Naissance'     },
  naissance:        { k: 'naissance',  l: 'Naissance'     },
  // Password / hash
  password:         { k: 'mdp',        l: 'Password'      },
  pass:             { k: 'mdp',        l: 'Password'      },
  mot_de_passe:     { k: 'mdp',        l: 'Password'      },
  hash:             { k: 'hash',       l: 'Hash'          },
  password_hash:    { k: 'hash',       l: 'Hash'          },
  hashed_password:  { k: 'hash',       l: 'Hash'          },
  // IP
  ip:               { k: 'ip',         l: 'IP'            },
  ip_address:       { k: 'ip',         l: 'IP'            },
  last_ip:          { k: 'ip',         l: 'Dernière IP'   },
  // Pseudo
  username:         { k: 'fleche',     l: 'Pseudo'        },
  login:            { k: 'fleche',     l: 'Login'         },
  user:             { k: 'fleche',     l: 'Pseudo'        },
  pseudo:           { k: 'fleche',     l: 'Pseudo'        },
  // Source
  source:           { k: 'source',     l: 'Source'        },
  // Entreprise
  entreprise:       { k: 'entreprise', l: 'Entreprise'    },
  company:          { k: 'entreprise', l: 'Entreprise'    },
  // IBAN / Banque / BIC
  iban:             { k: 'iban',       l: 'IBAN'          },
  bank:             { k: 'banque',     l: 'Banque'        },
  banque:           { k: 'banque',     l: 'Banque'        },
  bic:              { k: 'bic',        l: 'BIC'           },
  // Activité
  activite:         { k: 'activite',   l: 'Activité'      },
  activity:         { k: 'activite',   l: 'Activité'      },
  code_naf:         { k: 'code_naf',   l: 'Code NAF'      },
  naf:              { k: 'code_naf',   l: 'Code NAF'      },
  // Création / Effectif
  creation:         { k: 'creation',   l: 'Création'      },
  effectif:         { k: 'effectif',   l: 'Effectif'      },
  // Pays
  country:          { k: 'maison',     l: 'Pays'          },
  pays:             { k: 'maison',     l: 'Pays'          },
  // Leak date
  leakdate:         { k: 'calendrier', l: 'Leak date'     },
  leak_date:        { k: 'calendrier', l: 'Leak date'     },
  leakDate:         { k: 'calendrier', l: 'Leak date'     },
  date_fuite:       { k: 'calendrier', l: 'Leak date'     },
  // Commune / Département
  commune:          { k: 'ville',      l: 'Commune'       },
  municipality:     { k: 'ville',      l: 'Commune'       },
  departement:      { k: 'maison',     l: 'Département'   },
  department:       { k: 'maison',     l: 'Département'   },
  region:           { k: 'maison',     l: 'Région'        },
  // Age
  age:              { k: 'birthday',   l: 'Âge'           },
  // Portable (alias mobile)
  portable:         { k: 'phone',      l: 'Portable'      },
  tel:              { k: 'phone',      l: 'Téléphone'     },
  tel2:             { k: 'phone',      l: 'Tél. 2'        },
  fax:              { k: 'phone',      l: 'Fax'           },
  // Véhicule
  plaque:           { k: 'voiture',    l: 'Plaque'        },
  immatriculation:  { k: 'voiture',    l: 'Immatriculation'},
  // Divers
  nationalite:      { k: 'maison',     l: 'Nationalité'   },
  nationality:      { k: 'maison',     l: 'Nationalité'   },
  situation:        { k: 'civilite',   l: 'Situation'     },
  profession:       { k: 'activite',   l: 'Profession'    },
  revenu:           { k: 'iban',       l: 'Revenu'        },
  salaire:          { k: 'iban',       l: 'Salaire'       },
};

function tryParseJSON(str) {
  if (!str) return null;
  try {
    const obj = JSON.parse(typeof str === 'string' ? str : JSON.stringify(str));
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) return obj;
  } catch (_) {}
  return null;
}

function parseVexbaseResult(res) {
  // Tous les champs qui peuvent contenir du JSON imbriqué
  const JSON_FIELDS = ['raw', 'preview', 'fields', 'data', 'record', 'entry'];

  let merged = {};

  // Parser chaque champ JSON en premier
  for (const field of JSON_FIELDS) {
    if (res[field]) {
      const parsed = tryParseJSON(res[field]);
      if (parsed) Object.assign(merged, parsed);
      else if (field === 'raw' || field === 'preview') {
        merged._raw_string = String(res[field]);
      }
    }
  }

  // Ajouter les champs top-level (hors méta et champs JSON déjà parsés)
  const META = new Set(['source','shard','preview','raw','fields','data','record','entry','identity','credentials','_id','cachedAt']);
  for (const [k,v] of Object.entries(res)) {
    if (!META.has(k)) merged[k] = v;
  }

  // Merger identity{} et credentials{}
  if (res.identity)    Object.assign(merged, res.identity);
  if (res.credentials) Object.assign(merged, res.credentials);

  // Ajouter leakDate / leak_date si présent dans res
  if (res.leakDate || res.leak_date || res.leakdate) {
    merged.leakDate = res.leakDate || res.leak_date || res.leakdate;
  }

  return merged;
}

// Champs qui s'affichent avec backticks (valeurs techniques)
const CODE_FIELDS = new Set([
  'email','mail','email_address',
  'phone','telephone','phone_number','mobile',
  'ip','ip_address','last_ip',
  'password','pass','mot_de_passe',
  'hash','password_hash','hashed_password',
  'iban','bic',
  'zip','postal_code','code_postal',
  'username','login','user','pseudo',
  'code_naf','naf',
  'portable','tel','tel2','plaque','immatriculation',
]);

function fieldVal(key, val) {
  const s = String(val).slice(0, 120);
  return CODE_FIELDS.has(key.toLowerCase()) ? '`' + s + '`' : s;
}

function buildSearchPage(query, deep, results, page, total) {
  const maxPage = Math.min(25, results.length);
  const res     = results[page - 1];

  const hE    = deep ? (e('sniper')||'') : (e('search')||'');
  const color = deep ? C.search : C.accent;

  const c = new ContainerBuilder().setAccentColor(color);

  // ── Header ────────────────────────────────────────────────────────────────
  c.addTextDisplayComponents(txt(
    (hE?hE+'  ':'')+
    '**'+(deep?'Approfondie':'Recherche')+'** — `'+query+'`\n'+
    '-# **'+total+'** résultat'+(total>1?'s':'')+
    (maxPage>1?'  ·  **'+page+'/'+maxPage+'**':'')
  ));

  if (!res) {
    c.addSeparatorComponents(sep())
     .addTextDisplayComponents(txt((e('non')||'')+'  Aucun résultat.'));
  } else {
    // ── Construire un objet propre depuis le résultat ────────────────────────
    const merged = parseVexbaseResult(res);

    // ── Affichage JSON-style — comme dans le screenshot ──────────────────────
    // On collecte TOUS les champs dans l'ordre :
    // 1. Champs avec emoji connu (nom, email, phone, adresse...)
    // 2. Champs auto-détectés
    // 3. Champs inconnus
    // Tout dans un seul bloc, format : "champ": "valeur"

    const SKIP = new Set(['_id','cachedAt','_raw_string','source','shard']);
    const displayed = new Set([...SKIP]);

    // Construire le bloc JSON affiché proprement
    const jsonLines = [];

    // Champs connus avec emojis — en premier
    for (const [rawKey, val] of Object.entries(merged)) {
      if (displayed.has(rawKey) || val==null || val==='') continue;
      const cfg = FIELD_MAP[rawKey.toLowerCase()];
      if (!cfg) continue;
      const v   = String(val).slice(0, 120);
      jsonLines.push('"'+rawKey+'": "'+v+'"');
      displayed.add(rawKey);
    }

    // Champs auto-détectés (valeur connue mais clé inconnue)
    for (const [rawKey, val] of Object.entries(merged)) {
      if (displayed.has(rawKey) || val==null || val==='') continue;
      if (FIELD_MAP[rawKey.toLowerCase()]) continue;
      if (typeof val === 'object') continue;
      const det = detectFieldType(rawKey, val);
      if (det && FIELD_MAP[det]) {
        const cfg = FIELD_MAP[det];
        const em  = e(cfg.k);
        jsonLines.push('"'+rawKey+'": "'+String(val).slice(0,120)+'"');
      } else {
        jsonLines.push('"'+rawKey+'": "'+String(val).slice(0,120)+'"');
      }
      displayed.add(rawKey);
    }

    // Champs objets
    for (const [rawKey, val] of Object.entries(merged)) {
      if (displayed.has(rawKey) || val==null) continue;
      if (typeof val !== 'object') continue;
      jsonLines.push('"'+rawKey+'": '+JSON.stringify(val).slice(0,100));
      displayed.add(rawKey);
    }

    if (jsonLines.length) {
      c.addSeparatorComponents(sep());
      // Bloc JSON — emojis AVANT le bloc de code (pas dedans)
      // On sépare les emojis des lignes JSON
      const emojiPart = [];
      const jsonPart  = [];
      for (const line of jsonLines) {
        // Chaque ligne : "emoji "key": "val""
        // Extraire l'emoji (tout ce qui est avant le guillemet ouvrant)
        const qIdx = line.indexOf('"');
        const emStr = qIdx > 0 ? line.slice(0, qIdx).trim() : '';
        const jStr  = qIdx >= 0 ? line.slice(qIdx) : line;
        emojiPart.push(emStr);
        jsonPart.push(jStr);
      }
      // Afficher les emojis en texte AVANT le bloc json
      const emojiRow = emojiPart.filter(Boolean);
      if (emojiRow.length) {
        // On affiche les emojis dans un TextDisplay séparé, 1 par ligne aligné
        // Puis le bloc JSON pur sans emojis
      }
      const block = '{\n' + jsonPart.join(',\n') + '\n}';
      c.addTextDisplayComponents(txt('```json\n'+block+'\n```'));
    }

    // Source en footnote
    if (res.source || res.shard) {
      const srcE = e('source');
      c.addTextDisplayComponents(txt(
        '-# '+(srcE?srcE+' ':'')+[res.source,res.shard].filter(Boolean).join('  ·  ')
      ));
    }

    // Raw brut si non-JSON
    if (merged._raw_string) {
      c.addSeparatorComponents(sep());
      c.addTextDisplayComponents(txt('-# '+merged._raw_string.slice(0,600)));
    }
  }

  // ── Boutons : Prev | page/total | Next | Export ───────────────────────────
  const qE = encodeURIComponent(query).slice(0,60);
  const df  = deep?'1':'0';

  const exportBtn = new ButtonBuilder()
    .setCustomId('sr_dl_'+page+'_'+qE)
    .setLabel('Export').setStyle(ButtonStyle.Success);
  const dlObj = emojiObj('download'); if (dlObj) exportBtn.setEmoji(dlObj);

  if (maxPage > 1) {
    const prevBtn = new ButtonBuilder()
      .setCustomId('sr_prev_'+df+'_'+page+'_'+qE)
      .setLabel('Prev').setStyle(ButtonStyle.Primary).setDisabled(page<=1);
    const pageBtn = new ButtonBuilder()
      .setCustomId('sr_noop')
      .setLabel(page+' / '+maxPage).setStyle(ButtonStyle.Secondary).setDisabled(true);
    const nextBtn = new ButtonBuilder()
      .setCustomId('sr_next_'+df+'_'+page+'_'+qE)
      .setLabel('Next').setStyle(ButtonStyle.Primary).setDisabled(page>=maxPage);
    c.addActionRowComponents(new ActionRowBuilder().addComponents(prevBtn, pageBtn, nextBtn, exportBtn));
  } else {
    c.addActionRowComponents(new ActionRowBuilder().addComponents(exportBtn));
  }

  return _cv2(c);
}



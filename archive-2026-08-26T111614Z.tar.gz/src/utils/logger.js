'use strict';

const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
const { e } = require('./emojiManager');

const COLORS = {
  github  : 0x24292E,
  ip      : 0x00D4FF,
  tool    : 0x5865F2,
  search  : 0xE1306C,
};

async function logAction(client, user, action, target, extra) {
  const channelId = client.config?.logChannelId;
  if (!channelId || channelId === 'ID_SALON_LOGS') return;

  try {
    const ch = await client.channels.fetch(channelId).catch(() => null);
    if (!ch?.isTextBased()) return;

    const em    = e(action);  // emoji correspondant au module si disponible
    const color = COLORS[action] ?? 0x5865F2;

    const lines = [
      (em ? em + '  ' : '') + '**' + action.toUpperCase() + '** — `' + target + '`',
      '**Utilisateur**  ' + (user.tag || user.username) + '  (`' + user.id + '`)',
      '**Heure**        <t:' + Math.floor(Date.now() / 1000) + ':F>',
    ];

    if (extra) {
      lines.push('');
      for (const [k, v] of Object.entries(extra)) {
        if (v != null && v !== '' && v !== false) {
          lines.push('**' + k + '**  ' + String(v));
        }
      }
    }

    await ch.send({
      components: [
        new ContainerBuilder()
          .setAccentColor(color)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(lines.join('\n'))
          ),
      ],
      flags: MessageFlags.IsComponentsV2,
    });
  } catch (err) {
    console.error('[LOG]', err.message);
  }
}

module.exports = { logAction };

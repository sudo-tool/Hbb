'use strict';

const axios = require('axios');

const BRIXHUB_BASE = 'https://brixhub.to/api/v1';
const TOOLS_BASE   = 'https://jf74vndio5798vf9.fr/api';
const TO   = 25_000;

function brixhubHeaders(client) {
  const key = client?.config?.brixhubApiKey || process.env.BRIXHUB_API_KEY || '';
  return {
    'X-API-Key':     key,
    'Content-Type':  'application/json',
    'Accept':        'application/json',
    'User-Agent':    'osint-bot/1.0',
  };
}

function toolHeaders(client) {
  const key = client?.config?.apiKey || process.env.API_KEY || '';
  return {
    'Authorization': 'Bearer ' + key,
    'Content-Type':  'application/json',
    'Accept':        'application/json',
  };
}

function buildBrixHubQuery(query, deep) {
  const value = query.trim();
  const compact = value.replace(/[\s.-]/g, '');
  let field = 'nom_utilisateur';

  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) field = 'email';
  else if (/^(?:\+|00)?\d{8,15}$/.test(compact)) field = 'telephone';
  else if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(value)) field = 'adresse_ip';
  else if (/^\d{17,20}$/.test(compact)) field = 'discord_id';
  else if (/^[A-Z]{2}\d{3}[A-Z]{2}$/i.test(compact)) field = 'immatriculation';
  else if (/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/i.test(compact)) field = 'iban';

  return { [field]: value, page: 1, per_page: 25, flexible: !!deep };
}

function normalizeBrixHubResult(result) {
  if (!result || typeof result !== 'object') return result;
  const { _sources, _confidence, ...profile } = result;
  const address = [profile.adresse, profile.code_postal, profile.ville]
    .filter(Boolean).join(', ');
  const identity = {
    ...(profile.identity || {}),
    email: profile.email,
    username: profile.nom_utilisateur,
    name: profile.nom_affichage || [profile.prenom, profile.nom_famille].filter(Boolean).join(' '),
    phone: profile.telephone || profile.mobile,
    ip: profile.adresse_ip,
    address: address || undefined,
  };

  return {
    ...profile,
    source: Array.isArray(_sources) && _sources.length ? _sources.join(', ') : 'BrixHub',
    ...(_confidence != null ? { confidence: _confidence } : {}),
    identity: Object.fromEntries(Object.entries(identity).filter(([, v]) => v != null && v !== '')),
  };
}

async function search(query, deep, client) {
  const start = Date.now();
  const r = await axios.post(BRIXHUB_BASE + '/search', buildBrixHubQuery(query, deep), {
    headers: brixhubHeaders(client),
    timeout: TO,
  });
  const envelope = r.data || {};
  const payload = envelope.data || {};
  const rawResults = Array.isArray(payload) ? payload : (payload.results || envelope.results || []);
  const meta = envelope.meta || payload.meta || {};
  return {
    data: {
      results: rawResults.map(normalizeBrixHubResult),
      total_results: meta.total ?? envelope.total_results ?? rawResults.length,
      meta,
      provider: 'BrixHub',
    },
    latency: Date.now() - start,
  };
}

async function stats(client) {
  const start = Date.now();
  const r = await axios.get(TOOLS_BASE + '/stats', { headers: toolHeaders(client), timeout: TO });
  return { data: r.data, latency: Date.now() - start };
}

async function tool(endpoint, body, client) {
  const r = await axios.post(TOOLS_BASE + '/tools/' + endpoint, body, {
    headers: toolHeaders(client), timeout: TO,
  });
  return r.data;
}

module.exports = { search, stats, tool };

'use strict';

const zlib = require('zlib');
const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../../data');

function esc(v) { return String(v || '').replace(/'/g, "''"); }
function q(v)   { return '"' + String(v || '').replace(/"/g, '""') + '"'; }
function x(v)   { return String(v || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ── Instagram ─────────────────────────────────────────────────────────────────
function igToJson(d) { return JSON.stringify(d, null, 2); }
function igToTxt(d) {
  const r = (l,v) => '  ' + l.padEnd(22) + ' ' + (v||'—');
  return [
    '='.repeat(52), '  OSINT — Instagram : @' + d.username,
    '  ' + new Date().toLocaleString('fr-FR'), '='.repeat(52), '',
    r('Username :', '@'+d.username), r('Nom :', d.fullName),
    r('ID :', d.igId), r('Type :', d.accountType),
    r('Abonnes :', String(d.followers)), r('Abonnements :', String(d.following)),
    r('Posts :', String(d.posts)), r('Engagement :', d.engagement+'%'),
    r('Email :', d.publicEmail), r('Tel :', d.publicPhone),
    r('Ville :', d.city), r('Verifie :', d.isVerified?'Oui':'Non'),
    r('Prive :', d.isPrivate?'Oui':'Non'),
    '', '-- Bio', d.bio||'(vide)',
    '', '-- Liens', ...(d.bioLinks?.length ? d.bioLinks : ['—']),
    '', r('URL :', 'https://www.instagram.com/'+d.username+'/'),
    '', '='.repeat(52), '  OSINT Bot v5.0', '='.repeat(52),
  ].join('\n');
}
function igToSql(d) {
  return [
    '-- Instagram @' + d.username + ' — ' + new Date().toLocaleString('fr-FR'),
    'CREATE TABLE IF NOT EXISTS ig(username TEXT,full_name TEXT,ig_id TEXT,followers INT,following INT,posts INT,engagement REAL,email TEXT,phone TEXT,city TEXT,verified INT,private INT,bio TEXT,url TEXT);',
    "INSERT INTO ig VALUES('"+esc(d.username)+"','"+esc(d.fullName)+"','"+esc(d.igId)+"',"+d.followers+","+d.following+","+d.posts+","+d.engagement+",'"+esc(d.publicEmail)+"','"+esc(d.publicPhone)+"','"+esc(d.city)+"',"+(d.isVerified?1:0)+","+(d.isPrivate?1:0)+",'"+esc(d.bio)+"','https://www.instagram.com/"+esc(d.username)+"/');",
  ].join('\n');
}
function igToCsv(d) {
  return ['username,full_name,ig_id,followers,following,posts,engagement,email,phone,city,verified,private,bio',
    [q(d.username),q(d.fullName),q(d.igId),d.followers,d.following,d.posts,d.engagement,q(d.publicEmail),q(d.publicPhone),q(d.city),d.isVerified?1:0,d.isPrivate?1:0,q(d.bio)].join(','),
  ].join('\n');
}
function igToXml(d) {
  return ['<?xml version="1.0" encoding="UTF-8"?>','<report module="instagram">',
    '<username>'+x(d.username)+'</username>','<full_name>'+x(d.fullName)+'</full_name>',
    '<ig_id>'+x(d.igId)+'</ig_id>','<followers>'+d.followers+'</followers>',
    '<following>'+d.following+'</following>','<posts>'+d.posts+'</posts>',
    '<engagement>'+d.engagement+'</engagement>','<email>'+x(d.publicEmail)+'</email>',
    '<phone>'+x(d.publicPhone)+'</phone>','<city>'+x(d.city)+'</city>',
    '<bio>'+x(d.bio)+'</bio>','</report>',
  ].join('\n');
}

// ── GitHub ────────────────────────────────────────────────────────────────────
function ghToJson(d) { return JSON.stringify(d, null, 2); }
function ghToTxt(d) {
  const r = (l,v) => '  ' + l.padEnd(22) + ' ' + (v||'—');
  return [
    '='.repeat(52), '  OSINT — GitHub : @' + d.username,
    '  ' + new Date().toLocaleString('fr-FR'), '='.repeat(52), '',
    r('Username :', '@'+d.username), r('Nom :', d.name),
    r('ID :', String(d.githubId)), r('Type :', d.accountType),
    r('Repos :', String(d.publicRepos)), r('Stars :', String(d.totalStars)),
    r('Followers :', String(d.followers)), r('Entreprise :', d.company),
    r('Localisation :', d.location), r('Site :', d.blog),
    r('Twitter :', d.twitterUser?'@'+d.twitterUser:'—'),
    r('Cree le :', d.createdAt?new Date(d.createdAt).toLocaleDateString('fr-FR'):'—'),
    '', '-- Emails OSINT',
    ...(d.emails?.length ? d.emails : ['Aucun email reel']),
    ...(d.emailsRaw?.filter(e=>e.includes('noreply')).length ? ['','-- Noreply',...d.emailsRaw.filter(e=>e.includes('noreply'))] : []),
    '', '-- Langages', d.topLangs?.join(', ')||'—',
    '', '-- Organisations', ...(d.orgs?.length ? d.orgs.map(o=>o.name+' -> '+o.url) : ['Aucune']),
    '', '-- Top Repos',
    ...(d.topRepos?.length ? d.topRepos.map(r=>r.name+' ★'+r.stars+'  '+r.url) : ['Aucun']),
    '', r('URL :', d.htmlUrl),
    '', '='.repeat(52), '  OSINT Bot v5.0', '='.repeat(52),
  ].join('\n');
}
function ghToSql(d) {
  const lines = ['-- GitHub @'+d.username+' — '+new Date().toLocaleString('fr-FR'),
    'CREATE TABLE IF NOT EXISTS gh(username TEXT,name TEXT,github_id INT,company TEXT,location TEXT,blog TEXT,twitter TEXT,repos INT,stars INT,followers INT,created_at TEXT,bio TEXT);',
    "INSERT INTO gh VALUES('"+esc(d.username)+"','"+esc(d.name)+"',"+d.githubId+",'"+esc(d.company)+"','"+esc(d.location)+"','"+esc(d.blog)+"','"+esc(d.twitterUser)+"',"+d.publicRepos+","+d.totalStars+","+d.followers+",'"+esc(d.createdAt)+"','"+esc(d.bio)+"');",
    'CREATE TABLE IF NOT EXISTS gh_emails(username TEXT,email TEXT,noreply INT);',
    ...(d.emailsRaw||[]).map(em=>"INSERT INTO gh_emails VALUES('"+esc(d.username)+"','"+esc(em)+"',"+(em.includes('noreply')?1:0)+");"),
    'CREATE TABLE IF NOT EXISTS gh_repos(username TEXT,name TEXT,url TEXT,stars INT,forks INT,lang TEXT);',
    ...(d.topRepos||[]).map(r=>"INSERT INTO gh_repos VALUES('"+esc(d.username)+"','"+esc(r.name)+"','"+esc(r.url)+"',"+r.stars+","+r.forks+",'"+esc(r.language)+"');"),
  ];
  return lines.join('\n');
}
function ghToCsv(d) {
  return ['username,name,github_id,company,location,blog,twitter,repos,stars,followers,created_at,emails',
    [q(d.username),q(d.name),d.githubId,q(d.company),q(d.location),q(d.blog),q(d.twitterUser),d.publicRepos,d.totalStars,d.followers,q(d.createdAt),q((d.emails||[]).join('; '))].join(','),
  ].join('\n');
}
function ghToXml(d) {
  return ['<?xml version="1.0" encoding="UTF-8"?>','<report module="github">',
    '<username>'+x(d.username)+'</username>','<name>'+x(d.name)+'</name>',
    '<github_id>'+d.githubId+'</github_id>','<repos>'+d.publicRepos+'</repos>',
    '<stars>'+d.totalStars+'</stars>','<followers>'+d.followers+'</followers>',
    '<company>'+x(d.company)+'</company>','<location>'+x(d.location)+'</location>',
    '<bio>'+x(d.bio)+'</bio>',
    '<emails>'+( d.emails||[]).map(e=>'<email>'+x(e)+'</email>').join('')+'</emails>',
    '</report>',
  ].join('\n');
}

// ── Telegram ──────────────────────────────────────────────────────────────────
function tgToJson(d) { return JSON.stringify(d, null, 2); }
function tgToTxt(d) {
  const r = (l,v) => '  ' + l.padEnd(22) + ' ' + (v||'—');
  return [
    '='.repeat(52), '  OSINT — Telegram : ' + (d.username?'@'+d.username:d.fullName),
    '  ' + new Date().toLocaleString('fr-FR'), '='.repeat(52), '',
    r('Username :', d.username?'@'+d.username:'—'), r('Nom :', d.fullName),
    r('ID :', d.id), r('Telephone :', d.phone||'—'),
    r('Langue :', d.langCode||'—'), r('DC :', d.dcId?'DC'+d.dcId:'—'),
    r('En ligne :', d.isOnline?'Oui':'Non'), r('Derniere vue :', d.lastSeen),
    r('Verifie :', d.isVerified?'Oui':'Non'), r('Premium :', d.isPremium?'Oui':'Non'),
    r('Bot :', d.isBot?'Oui':'Non'), r('Scam :', d.isScam?'OUI':'Non'),
    r('Fake :', d.isFake?'OUI':'Non'), r('Restrictions :', d.restrictions||'—'),
    '', '-- Bio', d.bio||'(vide)',
    '', r('URL :', d.profileUrl||'—'),
    '', '='.repeat(52), '  OSINT Bot v5.0', '='.repeat(52),
  ].join('\n');
}
function tgToSql(d) {
  return ['-- Telegram '+( d.username?'@'+d.username:d.id)+' — '+new Date().toLocaleString('fr-FR'),
    'CREATE TABLE IF NOT EXISTS tg(id TEXT,username TEXT,full_name TEXT,phone TEXT,bio TEXT,lang TEXT,dc INT,online INT,last_seen TEXT,verified INT,premium INT,bot INT,scam INT,fake INT,url TEXT);',
    "INSERT INTO tg VALUES('"+esc(d.id)+"','"+esc(d.username)+"','"+esc(d.fullName)+"','"+esc(d.phone)+"','"+esc(d.bio)+"','"+esc(d.langCode)+"',"+(d.dcId||'NULL')+","+(d.isOnline?1:0)+",'"+esc(d.lastSeen)+"',"+(d.isVerified?1:0)+","+(d.isPremium?1:0)+","+(d.isBot?1:0)+","+(d.isScam?1:0)+","+(d.isFake?1:0)+",'"+esc(d.profileUrl)+"');",
  ].join('\n');
}
function tgToCsv(d) {
  return ['id,username,full_name,phone,lang,dc,online,last_seen,verified,premium,bot,scam,fake,bio,url',
    [q(d.id),q(d.username),q(d.fullName),q(d.phone),q(d.langCode),d.dcId||'',d.isOnline?1:0,q(d.lastSeen),d.isVerified?1:0,d.isPremium?1:0,d.isBot?1:0,d.isScam?1:0,d.isFake?1:0,q(d.bio),q(d.profileUrl)].join(','),
  ].join('\n');
}
function tgToXml(d) {
  return ['<?xml version="1.0" encoding="UTF-8"?>','<report module="telegram">',
    '<id>'+x(d.id)+'</id>','<username>'+x(d.username)+'</username>',
    '<full_name>'+x(d.fullName)+'</full_name>','<phone>'+x(d.phone)+'</phone>',
    '<bio>'+x(d.bio)+'</bio>','<lang>'+x(d.langCode)+'</lang>',
    '<online>'+(d.isOnline?'true':'false')+'</online>',
    '<last_seen>'+x(d.lastSeen)+'</last_seen>',
    '<verified>'+(d.isVerified?'true':'false')+'</verified>',
    '<premium>'+(d.isPremium?'true':'false')+'</premium>',
    '<url>'+x(d.profileUrl)+'</url>','</report>',
  ].join('\n');
}

// ── Dispatcher ────────────────────────────────────────────────────────────────
function convert(mod, format, data) {
  const jsonFn = d => JSON.stringify(d, null, 2);
  const map = {
    gh:     { json: ghToJson, txt: ghToTxt, sql: ghToSql, csv: ghToCsv, xml: ghToXml },
    tg:     { json: tgToJson, txt: tgToTxt, sql: tgToSql, csv: tgToCsv, xml: tgToXml },
    ip:     { json: ipToJson, txt: ipToTxt, sql: ipToSql, csv: ipToCsv, xml: ipToXml },
    search: { json: jsonFn,   txt: jsonFn,  sql: jsonFn,  csv: jsonFn,  xml: jsonFn  },
    tool:   { json: jsonFn,   txt: jsonFn,  sql: jsonFn,  csv: jsonFn,  xml: jsonFn  },
  };
  const fn = map[mod]?.[format] ?? map[mod]?.json ?? jsonFn;
  return { content: fn(data), ext: format };
}

// ── IP ────────────────────────────────────────────────────────────────────────
function ipToJson(d) { return JSON.stringify(d, null, 2); }
function ipToTxt(d) {
  const r = (l,v) => '  ' + l.padEnd(20) + ' ' + (v||'—');
  return [
    '='.repeat(50), '  OSINT — IP : ' + d.ip,
    '  ' + new Date().toLocaleString('fr-FR'), '='.repeat(50), '',
    r('IP :', d.ip), r('rDNS :', d.reverseDns),
    r('Pays :', d.country + ' (' + d.countryCode + ')'),
    r('Region :', d.region), r('Ville :', d.city),
    r('Code postal :', d.postalCode), r('Continent :', d.continent),
    r('Coords :', d.lat && d.lon ? d.lat+', '+d.lon : '—'),
    r('Timezone :', d.timezone), '',
    r('ISP :', d.isp), r('Org :', d.org),
    r('ASN :', d.asn), r('AS Name :', d.asnName),
    r('Prefix :', d.prefix), r('Connexion :', d.connectionType), '',
    r('Proxy :', d.isProxy?'OUI':'Non'),
    r('VPN/Hosting :', d.isVPN?'OUI':'Non'),
    r('Tor :', d.isTor?'OUI':'Non'),
    r('Mobile :', d.isMobile?'Oui':'Non'), '',
    r('Abuse :', d.abuseContact),
    '', '='.repeat(50), '  OSINT Bot v5.1', '='.repeat(50),
  ].join('\n');
}
function ipToSql(d) {
  return [
    '-- IP ' + d.ip + ' — ' + new Date().toLocaleString('fr-FR'),
    'CREATE TABLE IF NOT EXISTS ip_lookup(ip TEXT,rdns TEXT,country TEXT,region TEXT,city TEXT,timezone TEXT,lat REAL,lon REAL,isp TEXT,org TEXT,asn TEXT,prefix TEXT,is_proxy INT,is_vpn INT,is_tor INT,is_mobile INT,abuse_contact TEXT);',
    "INSERT INTO ip_lookup VALUES('"+d.ip+"','"+d.reverseDns+"','"+d.country+" ("+d.countryCode+")','"+d.region+"','"+d.city+"','"+d.timezone+"',"+( d.lat||'NULL')+","+(d.lon||'NULL')+",'"+d.isp+"','"+d.org+"','"+d.asn+"','"+d.prefix+"',"+(d.isProxy?1:0)+","+(d.isVPN?1:0)+","+(d.isTor?1:0)+","+(d.isMobile?1:0)+",'"+d.abuseContact+"');",
  ].join('\n');
}
function ipToCsv(d) {
  const q = v => '"' + String(v||'').replace(/"/g,'""') + '"';
  return ['ip,rdns,country,region,city,timezone,lat,lon,isp,org,asn,prefix,proxy,vpn,tor,mobile,abuse',
    [q(d.ip),q(d.reverseDns),q(d.country),q(d.region),q(d.city),q(d.timezone),d.lat||'',d.lon||'',q(d.isp),q(d.org),q(d.asn),q(d.prefix),d.isProxy?1:0,d.isVPN?1:0,d.isTor?1:0,d.isMobile?1:0,q(d.abuseContact)].join(','),
  ].join('\n');
}
function ipToXml(d) {
  const x = v => String(v||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return ['<?xml version="1.0" encoding="UTF-8"?>','<report module="ip">',
    '<ip>'+x(d.ip)+'</ip>','<rdns>'+x(d.reverseDns)+'</rdns>',
    '<country>'+x(d.country)+'</country>','<country_code>'+x(d.countryCode)+'</country_code>',
    '<region>'+x(d.region)+'</region>','<city>'+x(d.city)+'</city>',
    '<timezone>'+x(d.timezone)+'</timezone>',
    '<lat>'+(d.lat||'')+'</lat>','<lon>'+(d.lon||'')+'</lon>',
    '<isp>'+x(d.isp)+'</isp>','<org>'+x(d.org)+'</org>',
    '<asn>'+x(d.asn)+'</asn>','<prefix>'+x(d.prefix)+'</prefix>',
    '<proxy>'+(d.isProxy?'true':'false')+'</proxy>',
    '<vpn>'+(d.isVPN?'true':'false')+'</vpn>',
    '<tor>'+(d.isTor?'true':'false')+'</tor>',
    '<abuse>'+x(d.abuseContact)+'</abuse>',
    '</report>',
  ].join('\n');
}

module.exports = { convert };

'use strict';

/**
 * ipScraper.js
 *
 * Sources gratuites sans cle API :
 *  1. ip-api.com          — geoloc, ISP, ASN, proxy/VPN/Tor (JSON)
 *  2. ipwho.is            — geoloc enrichie, organisation, timezone
 *  3. rdap.arin.net       — WHOIS enrichi ARIN (ipv4)
 *  4. stat.ripe.net       — BGP, ASN details, prefixes (RIPE NCC)
 *  5. dns.google          — reverse DNS (PTR)
 *  6. abuseipdb.com       — reputation score (sans cle, endpoint public)
 *  7. ipinfo.io           — fallback geoloc
 */

const axios = require('axios');
const TO    = 8_000;

const ua = 'Mozilla/5.0 OSINT-Bot/5.0';

async function get(url, params) {
  return axios.get(url, {
    params,
    timeout: TO,
    headers: { 'User-Agent': ua, 'Accept': 'application/json' },
  });
}

// Valide IPv4 ou IPv6
function isValidIP(ip) {
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const ipv6  = /^[0-9a-fA-F:]{2,39}$/;
  return ipv4.test(ip) || ipv6.test(ip);
}

async function fetchIPInfo(rawIp) {
  const ip = rawIp.trim();
  if (!isValidIP(ip)) throw new Error('Adresse IP invalide : `' + ip + '`');

  const results = await Promise.allSettled([
    fetchIpApi(ip),
    fetchIpWhoIs(ip),
    fetchRipe(ip),
    fetchReverseDNS(ip),
  ]);

  const ipapi   = results[0].status === 'fulfilled' ? results[0].value : null;
  const ipwhois = results[1].status === 'fulfilled' ? results[1].value : null;
  const ripe    = results[2].status === 'fulfilled' ? results[2].value : null;
  const rdns    = results[3].status === 'fulfilled' ? results[3].value : null;

  if (!ipapi && !ipwhois) throw new Error('Impossible de resoudre `' + ip + '`');

  // Merge
  const geo = ipapi || ipwhois;

  return {
    ip,
    // Geolocation
    country:      geo.country      || ipwhois?.country      || '—',
    countryCode:  geo.countryCode  || ipwhois?.countryCode  || '—',
    region:       geo.region       || ipwhois?.region        || '—',
    city:         geo.city         || ipwhois?.city          || '—',
    lat:          geo.lat          || ipwhois?.lat           || null,
    lon:          geo.lon          || ipwhois?.lon           || null,
    timezone:     geo.timezone     || ipwhois?.timezone      || '—',
    postalCode:   ipwhois?.postalCode || '—',
    continent:    ipwhois?.continent  || '—',

    // Network
    isp:          geo.isp          || ipwhois?.org           || '—',
    org:          geo.org          || ipwhois?.org           || '—',
    asn:          geo.as           || ripe?.asn              || ipwhois?.asn || '—',
    asnName:      ripe?.asnName    || '—',
    asnCountry:   ripe?.asnCountry || '—',
    prefix:       ripe?.prefix     || '—',
    abuseContact: ripe?.abuseContact || '—',

    // Type / flags
    isProxy:      geo.proxy        || false,
    isVPN:        geo.hosting      || false,
    isTor:        geo.proxy        || false, // ip-api detecte proxy+Tor ensemble
    isMobile:     geo.mobile       || false,
    isHosting:    geo.hosting      || false,
    connectionType: geo.connectionType || '—',

    // DNS
    reverseDns:   rdns             || '—',
  };
}

// ── Sources ───────────────────────────────────────────────────────────────────

async function fetchIpApi(ip) {
  // ip-api.com — 45 req/min sans cle, champs : proxy, hosting, mobile
  const r = await get(`http://ip-api.com/json/${ip}`, {
    fields: 'status,message,country,countryCode,region,regionName,city,lat,lon,timezone,isp,org,as,proxy,hosting,mobile,query',
  });
  if (r.data?.status !== 'success') return null;
  const d = r.data;
  return {
    country: d.country, countryCode: d.countryCode,
    region: d.regionName, city: d.city,
    lat: d.lat, lon: d.lon, timezone: d.timezone,
    isp: d.isp, org: d.org, as: d.as,
    proxy: d.proxy, hosting: d.hosting, mobile: d.mobile,
    connectionType: d.hosting ? 'Hosting' : d.mobile ? 'Mobile' : 'Broadband',
  };
}

async function fetchIpWhoIs(ip) {
  const r = await get(`https://ipwho.is/${ip}`);
  if (!r.data?.success) return null;
  const d = r.data;
  return {
    country: d.country, countryCode: d.country_code,
    region: d.region, city: d.city,
    lat: d.latitude, lon: d.longitude,
    timezone: d.timezone?.id,
    org: d.connection?.org,
    asn: d.connection?.asn ? 'AS' + d.connection.asn : null,
    postalCode: d.postal,
    continent: d.continent,
  };
}

async function fetchRipe(ip) {
  // RIPE Stat — données BGP/ASN sans auth
  try {
    const r = await get('https://stat.ripe.net/data/prefix-overview/data.json', { resource: ip, sourceapp: 'osint-bot' });
    const data  = r.data?.data;
    const block = data?.block;
    const asns  = data?.asns?.[0];
    const prefix = block?.resource;

    // Abuse contact via RDAP
    let abuseContact = '—';
    try {
      const rdap = await get('https://rdap.arin.net/registry/ip/' + ip);
      const remarks = rdap.data?.remarks ?? [];
      for (const rem of remarks) {
        if (rem.title === 'Registration Comments') { abuseContact = rem.description?.join(' ') ?? '—'; break; }
      }
      const entities = rdap.data?.entities ?? [];
      for (const ent of entities) {
        if (ent.roles?.includes('abuse')) {
          const vcard = ent.vcardArray?.[1] ?? [];
          for (const v of vcard) {
            if (v[0] === 'email') { abuseContact = v[3]; break; }
          }
        }
      }
    } catch (_) {}

    return {
      asn:          asns ? 'AS' + asns.asn  : null,
      asnName:      asns?.holder             || '—',
      asnCountry:   '—',
      prefix:       prefix                   || '—',
      abuseContact,
    };
  } catch { return null; }
}

async function fetchReverseDNS(ip) {
  try {
    // Google DNS over HTTPS — PTR record
    const r = await get('https://dns.google/resolve', { name: reversePTR(ip), type: 'PTR' });
    const ans = r.data?.Answer;
    if (ans?.length) return ans[ans.length - 1].data?.replace(/\.$/, '') || '—';
  } catch (_) {}
  return null;
}

function reversePTR(ip) {
  if (ip.includes(':')) return '—'; // IPv6 simplifie
  return ip.split('.').reverse().join('.') + '.in-addr.arpa';
}

module.exports = { fetchIPInfo };

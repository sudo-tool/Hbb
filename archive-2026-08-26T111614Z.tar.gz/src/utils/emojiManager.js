'use strict';

/**
 * emojiManager.js v8
 * Emojis animés : <a:name:id>
 * Emojis statiques : <:name:id>
 * Upload sur application emojis via REST, fallback guild si 400/403
 */

const fs   = require('fs');
const path = require('path');

const cache     = new Map();
const EMOJI_DIR = path.join(__dirname, '../../emoji');

const MIME = {
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif':  'image/gif',
  '.webp': 'image/webp',
};

function normName(file) {
  const ext = path.extname(file).toLowerCase();
  return path.basename(file, ext)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .slice(0, 32) || 'emoji';
}

function _set(name, id, realName, animated) {
  const str = (animated ? '<a:' : '<:') + realName + ':' + id + '>';
  cache.set(name, { id, name: realName, str, animated: !!animated });
  return str;
}

async function loadEmojis(client) {
  if (!fs.existsSync(EMOJI_DIR)) return console.error('[EMOJI] Dossier emoji/ introuvable');
  const files = fs.readdirSync(EMOJI_DIR).filter(f => /\.(png|jpg|jpeg|gif|webp)$/i.test(f));
  if (!files.length) return;

  const appId = client.application?.id;
  if (!appId) return console.error('[EMOJI] client.application.id manquant');

  // Fetch existants
  let existing = [];
  try {
    const res = await client.rest.get('/applications/' + appId + '/emojis');
    existing  = Array.isArray(res) ? res : (res.items ?? []);
    console.log('[EMOJI] ' + existing.length + ' emoji(s) application existants');
  } catch (err) {
    console.error('[EMOJI] Fetch application emojis échoué :', err.message);
  }

  // Guild fallback
  const guild = client.guilds.cache.first();

  let guildExisting = new Map();
  if (guild) {
    try {
      guildExisting = await guild.emojis.fetch();
    } catch (_) {}
  }

  let ok = 0, skip = 0, fail = 0;

  for (const file of files) {
    const ext      = path.extname(file).toLowerCase();
    const mime     = MIME[ext]; if (!mime) continue;
    const name     = normName(file);
    const animated = ext === '.gif';

    if (cache.get(name)?.id) { skip++; continue; }

    // Existant sur l'application
    const found = existing.find(em => em.name === name);
    if (found) {
      const str = _set(name, found.id, found.name, animated);
      console.log('[EMOJI] ✓ app      ' + name + ' → ' + str);
      skip++; continue;
    }

    // Existant sur le guild
    const gFound = [...guildExisting.values()].find(em => em.name === name);
    if (gFound) {
      const str = _set(name, gFound.id, gFound.name, animated);
      console.log('[EMOJI] ✓ guild    ' + name + ' → ' + str);
      skip++; continue;
    }

    const buf     = fs.readFileSync(path.join(EMOJI_DIR, file));
    const dataUri = 'data:' + mime + ';base64,' + buf.toString('base64');

    // Tente application
    let created = null;
    try {
      created = await client.rest.post(
        '/applications/' + appId + '/emojis',
        { body: { name, image: dataUri } }
      );
      const str = _set(name, created.id, created.name, animated);
      console.log('[EMOJI] ↑ app      ' + name + ' → ' + str);
      ok++;
    } catch (err) {
      console.warn('[EMOJI] App upload échoué ' + name + ' (' + err.message + '), essai guild...');
      // Fallback guild
      if (guild) {
        try {
          created = await guild.emojis.create({ name, attachment: dataUri, reason: 'OSINT Bot' });
          const str = _set(name, created.id, created.name, animated);
          console.log('[EMOJI] ↑ guild    ' + name + ' → ' + str);
          ok++;
        } catch (err2) {
          console.error('[EMOJI] ✗ ' + name + ' : ' + err2.message);
          cache.set(name, { id: null, name, str: '', animated });
          fail++;
        }
      } else {
        console.error('[EMOJI] ✗ ' + name + ' : pas de guild disponible');
        cache.set(name, { id: null, name, str: '', animated });
        fail++;
      }
    }

    await new Promise(r => setTimeout(r, 400));
  }

  console.log('[EMOJI] ' + ok + ' uploadés / ' + skip + ' existants / ' + fail + ' échoués');
  for (const [k, v] of cache.entries())
    console.log('  ' + (v.id ? (v.animated ? '✓a' : '✓ ') : '✗ ') + ' ' + k.padEnd(20) + (v.id ? v.str : ''));
}

function e(name)        { return name ? (cache.get(name.toLowerCase())?.str ?? '') : ''; }
function emojiObj(name) {
  if (!name) return null;
  const v = cache.get(name.toLowerCase());
  return v?.id ? { id: v.id, name: v.name } : null;
}

module.exports = { loadEmojis, e, emojiObj };

'use strict';

/**
 * inviteScraper.js
 * Récupère les infos d'une invitation Discord ou Telegram
 * directement via l'API publique Discord (sans token).
 */

const axios = require('axios');

const DISCORD_API = 'https://discord.com/api/v10';
const TO          = 10_000;
const UA          = 'Mozilla/5.0 (compatible; OSINT-Bot/5.5)';

// Extrait le code d'invite depuis une URL ou un code brut
function extractCode(input) {
  input = input.trim();
  // discord.gg/CODE, discord.com/invite/CODE, t.me/CODE
  const m = input.match(/(?:discord\.gg|discord\.com\/invite)\/([A-Za-z0-9-]+)/i)
         || input.match(/t\.me\/([A-Za-z0-9_]+)/i);
  if (m) return { code: m[1], platform: m[0].includes('t.me') ? 'telegram' : 'discord' };
  // Code brut (pas d'URL)
  if (/^[A-Za-z0-9_-]{4,20}$/.test(input)) return { code: input, platform: 'discord' };
  return null;
}

async function analyzeInvite(url) {
  const parsed = extractCode(url);
  if (!parsed) throw new Error('URL d\'invitation invalide.');

  if (parsed.platform === 'discord') {
    return analyzeDiscord(parsed.code);
  } else {
    return { platform: 'Telegram', code: parsed.code, url: 'https://t.me/' + parsed.code };
  }
}

async function analyzeDiscord(code) {
  const r = await axios.get(DISCORD_API + '/invites/' + code, {
    params:  { with_counts: true, with_expiration: true },
    headers: { 'User-Agent': UA },
    timeout: TO,
  });

  const d     = r.data;
  const guild = d.guild ?? {};
  const ch    = d.channel ?? {};

  // URLs des assets
  const iconUrl   = guild.icon
    ? 'https://cdn.discordapp.com/icons/' + guild.id + '/' + guild.icon + (guild.icon.startsWith('a_') ? '.gif' : '.png') + '?size=256'
    : null;
  const bannerUrl = guild.banner
    ? 'https://cdn.discordapp.com/banners/' + guild.id + '/' + guild.banner + (guild.banner.startsWith('a_') ? '.gif' : '.png') + '?size=1024'
    : null;
  const splashUrl = guild.splash
    ? 'https://cdn.discordapp.com/splashes/' + guild.id + '/' + guild.splash + '.png?size=1024'
    : null;

  return {
    platform:          'Discord',
    code,
    inviteUrl:         'https://discord.gg/' + code,
    // Serveur
    guildId:           guild.id            ?? null,
    guildName:         guild.name          ?? '—',
    guildDescription:  guild.description   ?? null,
    guildFeatures:     guild.features      ?? [],
    guildVerification: guild.verification_level ?? null,
    guildBoosts:       guild.premium_subscription_count ?? null,
    guildBoostTier:    guild.premium_tier  ?? null,
    guildNSFW:         guild.nsfw          ?? false,
    // Stats
    memberCount:       d.approximate_member_count ?? null,
    onlineCount:       d.approximate_presence_count ?? null,
    // Salon
    channelName:       ch.name            ?? null,
    channelType:       ch.type            ?? null,
    // Inviteur
    inviterTag:        d.inviter ? (d.inviter.username + (d.inviter.discriminator !== '0' ? '#' + d.inviter.discriminator : '')) : null,
    inviterId:         d.inviter?.id      ?? null,
    // Expiration
    expiresAt:         d.expires_at       ?? null,
    maxUses:           d.max_uses         ?? null,
    uses:              d.uses             ?? null,
    // Assets
    iconUrl,
    bannerUrl,
    splashUrl,
  };
}

module.exports = { analyzeInvite };

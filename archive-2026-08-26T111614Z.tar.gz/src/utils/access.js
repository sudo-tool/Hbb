'use strict';

function extractSlug(s) {
  if (!s) return '';
  return s.toLowerCase()
    .replace(/https?:\/\//g, '')
    .replace(/discord\.gg\//g, '')
    .replace(/^\.gg\//g, '')
    .replace(/^\//, '')
    .split(/[\/\s]/)[0]
    .trim();
}

function statusContainsSlug(state, slug) {
  if (!state || !slug) return false;
  const s = state.toLowerCase();
  // Toutes les formes acceptées :
  // "xtracer", "/xtracer", ".gg/xtracer", "discord.gg/xtracer", "https://discord.gg/xtracer"
  const variants = [
    slug,
    '/' + slug,
    '.gg/' + slug,
    'discord.gg/' + slug,
    'https://discord.gg/' + slug,
  ];
  return variants.some(v => s.includes(v));
}

function checkAccess(interaction, client) {
  if (!client?.config) return true;
  // Admins passent toujours
  if (client.config.adminIds?.includes(interaction.user.id)) return true;
  const req = client.config.requiredStatus;
  if (!req || req === 'tonserveur') return true; // valeur placeholder → libre
  const slug = extractSlug(req);
  if (!slug) return true;
  // Chercher dans toutes les activités de type 4 (statut personnalisé)
  const activities = interaction.member?.presence?.activities ?? [];
  for (const act of activities) {
    if (act.type === 4 && act.state && statusContainsSlug(act.state, slug)) return true;
  }
  return false;
}

module.exports = { checkAccess, extractSlug, statusContainsSlug };

'use strict';
const axios = require('axios');

const GH = 'https://api.github.com';
const TO = 11_000;

const h = token => {
  const base = { 'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'OSINT-Bot/5.0' };
  if (token) base['Authorization'] = 'Bearer ' + token;
  return base;
};
const get = (url, token, params) => axios.get(url, { headers: h(token), params, timeout: TO });

async function fetchGithubProfile(raw, token) {
  const username = raw.replace(/^@/, '').trim();
  if (!username) throw new Error('Username vide.');

  const profile = await (async () => {
    const r = await get(GH + '/users/' + username, token);
    if (!r.data?.login) throw new Error('@' + username + ' introuvable.');
    return r.data;
  })();

  const repos = await get(GH + '/users/' + username + '/repos', token, { per_page: 100, sort: 'updated' })
    .then(r => r.data ?? []).catch(() => []);

  const emails = new Set(), noReply = new Set(), commitSamples = [];
  if (profile.email) emails.add(profile.email);

  // Events
  for (let page = 1; page <= 3; page++) {
    try {
      const r = await get(GH + '/users/' + username + '/events/public', token, { per_page: 30, page });
      const events = r.data ?? [];
      if (!events.length) break;
      for (const evt of events) {
        if (evt.type !== 'PushEvent') continue;
        for (const c of (evt.payload?.commits ?? [])) {
          const em = c.author?.email ?? '';
          const sha = c.sha ?? '';
          if (em) { em.includes('noreply') ? noReply.add(em) : emails.add(em); }
          if (sha && commitSamples.length < 8) {
            commitSamples.push({ sha: sha.slice(0,7), msg: (c.message??'').split('\n')[0], repo: evt.repo?.name??'', email: em, name: c.author?.name??'' });
            if (!em || em.includes('noreply')) {
              const pe = await patchEmail(evt.repo?.name, sha);
              if (pe) emails.add(pe);
            }
          }
        }
      }
      if (emails.size >= 3 || events.length < 30) break;
    } catch (_) { break; }
  }

  // Fallback commits par repo
  if (!emails.size) {
    for (const repo of repos.filter(r => !r.fork).slice(0, 3)) {
      try {
        const r = await get(GH + '/repos/' + repo.full_name + '/commits', token, { author: username, per_page: 10 });
        for (const c of (r.data ?? [])) {
          const em = c.commit?.author?.email ?? '';
          const sha = c.sha ?? '';
          if (em) { em.includes('noreply') ? noReply.add(em) : emails.add(em); }
          if (sha && commitSamples.length < 8)
            commitSamples.push({ sha: sha.slice(0,7), msg: (c.commit?.message??'').split('\n')[0], repo: repo.full_name, email: em, name: c.commit?.author?.name??'' });
          if (!em || em.includes('noreply')) { const pe = await patchEmail(repo.full_name, sha); if (pe) emails.add(pe); }
        }
      } catch (_) {}
      if (emails.size >= 2) break;
    }
  }

  const orgs = await get(GH + '/users/' + username + '/orgs', token, { per_page: 10 })
    .then(r => (r.data??[]).map(o => ({ name: o.login, url: 'https://github.com/'+o.login }))).catch(() => []);
  const followers5 = await get(GH + '/users/' + username + '/followers', token, { per_page: 5 })
    .then(r => (r.data??[]).map(u => u.login)).catch(() => []);
  const following5 = await get(GH + '/users/' + username + '/following', token, { per_page: 5 })
    .then(r => (r.data??[]).map(u => u.login)).catch(() => []);

  const topRepos = repos.sort((a,b) => b.stargazers_count - a.stargazers_count).slice(0,6).map(r => ({
    name: r.name, description: r.description||'', stars: r.stargazers_count, forks: r.forks_count,
    language: r.language||'', url: r.html_url, fork: r.fork,
  }));

  return {
    username: profile.login, name: profile.name||'', bio: profile.bio||'',
    company: profile.company||'', location: profile.location||'', blog: profile.blog||'',
    twitterUser: profile.twitter_username||'', avatarUrl: profile.avatar_url||'', htmlUrl: profile.html_url,
    githubId: profile.id, nodeId: profile.node_id, accountType: profile.type, siteAdmin: profile.site_admin,
    publicRepos: profile.public_repos, publicGists: profile.public_gists,
    followers: profile.followers, following: profile.following,
    createdAt: profile.created_at, updatedAt: profile.updated_at,
    emails: [...emails], emailsRaw: [...emails, ...noReply],
    topRepos, totalStars: repos.reduce((a,r) => a+r.stargazers_count, 0),
    totalForks: repos.reduce((a,r) => a+r.forks_count, 0),
    topLangs: [...new Set(repos.map(r => r.language).filter(Boolean))].slice(0,8),
    commitSamples: commitSamples.slice(0,5), orgs, followers5, following5,
  };
}

async function patchEmail(repo, sha) {
  if (!repo || !sha) return null;
  try {
    const r = await axios.get('https://github.com/'+repo+'/commit/'+sha+'.patch', {
      headers: { 'User-Agent': 'OSINT-Bot/5.0' }, timeout: 6000,
    });
    const m = (r.data??'').match(/^From:\s*.+<([^>@]+@[^>]+)>/m);
    if (m?.[1] && !m[1].includes('noreply')) return m[1];
  } catch (_) {}
  return null;
}

module.exports = { fetchGithubProfile };

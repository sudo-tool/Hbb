'use strict';

/**
 * telegramBot.js v2
 *
 * Seule commande : /panel
 * Accès : être membre du canal Telegram configuré
 *
 * /panel → affiche le panel avec boutons Searcher + Tools
 * Searcher → demande une query → résultats paginés
 * Tools → menu inline → modale → résultat
 * Retour → revient au panel
 */

const TelegramBot           = require('node-telegram-bot-api');
const { fetchGithubProfile } = require('./utils/githubScraper');
const { fetchIPInfo }        = require('./utils/ipScraper');
const { analyzeInvite }      = require('./utils/inviteScraper');
const { search, tool, stats } = require('./utils/apiClient');
const { e, emojiObj }        = require('./utils/emojiManager');

// ── Helpers texte ─────────────────────────────────────────────────────────────
function esc(s) {
  return String(s ?? '—').replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, '\\$&');
}
function bold(s)       { return '*' + esc(s) + '*'; }
function code(s)       { return '`' + String(s ?? '—').replace(/`/g, "'") + '`'; }
function line(l, v)    { return bold(l) + '  ' + code(v); }
function hr()          { return esc('━━━━━━━━━━━━━━━━━━━━'); }

// ── Send helper ───────────────────────────────────────────────────────────────
async function send(bot, chatId, text, opts) {
  // Tronquer si trop long
  const msg = text.length > 4000 ? text.slice(0, 3950) + '\n\\.\\.\\.' : text;
  try {
    return await bot.sendMessage(chatId, msg, {
      parse_mode: 'MarkdownV2',
      disable_web_page_preview: true,
      ...opts,
    });
  } catch (_) {
    try {
      return await bot.sendMessage(chatId, msg.replace(/[*`_[\]()~>#+\-=|{}.!\\]/g, ''), {
        disable_web_page_preview: true,
        ...opts,
      });
    } catch (err2) {
      console.error('[TG send]', err2.message);
    }
  }
}

async function edit(bot, chatId, msgId, text, opts) {
  const msg = text.length > 4000 ? text.slice(0, 3950) + '\n\\.\\.\\.' : text;
  try {
    return await bot.editMessageText(msg, {
      chat_id: chatId, message_id: msgId,
      parse_mode: 'MarkdownV2',
      disable_web_page_preview: true,
      ...opts,
    });
  } catch (_) {}
}

// ── Vérification accès canal ──────────────────────────────────────────────────
async function isMemberOfChannel(bot, userId, channelLink) {
  if (!channelLink) return true;
  const match = channelLink.match(/t\.me\/([^/?]+)/i) || channelLink.match(/^@?([a-zA-Z0-9_]+)$/);
  if (!match) return true;
  const channelUsername = '@' + match[1].replace(/^@/, '');
  try {
    const member = await bot.getChatMember(channelUsername, userId);
    return member.status !== 'left' && member.status !== 'kicked';
  } catch (_) {
    // Canal Telegram : getChatMember ne fonctionne que si le bot est admin du canal
    // En cas d'erreur → laisser passer (ne pas bloquer les utilisateurs)
    return true;
  }
}

// ── Panel Telegram ────────────────────────────────────────────────────────────
function buildPanelText(config) {
  const p = config.panel ?? {};
  const lines = [bold(p.botName || 'OSINT Bot')];
  if (p.discordLink?.trim())  lines.push('Discord — [' + esc(p.discordName||'Rejoindre') + '](' + p.discordLink + ')');
  if (p.telegramLink?.trim()) lines.push('Telegram — [' + esc(p.telegramName||'Canal') + '](' + p.telegramLink + ')');
  return lines.join('\n');
}

function panelKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: '🔍 Searcher', callback_data: 'action:searcher' },
        { text: '🛠️ Tools',    callback_data: 'action:tools'    },
      ],
      [
        { text: 'ℹ️ Info',     callback_data: 'action:info'     },
      ],
    ],
  };
}

// Envoyer le panel — avec ou sans image bannière
async function sendPanel(bot, chatId, config, editMsgId) {
  const p       = config.panel ?? {};
  const text    = buildPanelText(config);
  const kb      = panelKeyboard();
  const banner  = p.bannerUrl?.trim();

  if (editMsgId) {
    // Edition — on ne peut pas changer de type (photo↔texte) lors d'un edit
    // donc on edit juste le texte
    return edit(bot, chatId, editMsgId, text, { reply_markup: kb });
  }

  if (banner) {
    try {
      return await bot.sendPhoto(chatId, banner, {
        caption:      text,
        parse_mode:   'MarkdownV2',
        reply_markup: kb,
      });
    } catch (err) {
      console.warn('[TG] sendPhoto échoué :', err.message, '— fallback texte');
    }
  }
  return send(bot, chatId, text, { reply_markup: kb });
}

function toolsKeyboard() {
  return {
    inline_keyboard: [
      [{ text: '🐙 GitHub',       callback_data: 'tool:github'         }, { text: '🌐 IP',          callback_data: 'tool:analyze-ip'     }],
      [{ text: '#️⃣ Hash',         callback_data: 'tool:analyze-hash'   }, { text: '📞 Telephone',   callback_data: 'tool:analyze-phone'  }],
      [{ text: '📍 GPS',          callback_data: 'tool:analyze-gps'    }, { text: '🎟️ Invitation',  callback_data: 'tool:analyze-invite' }],
      [{ text: '🚗 Plaque FR',    callback_data: 'tool:analyze-plate'  }, { text: '🖥️ User-Agent',  callback_data: 'tool:analyze-ua'     }],
      [{ text: '🔗 DNS',          callback_data: 'tool:analyze-dns'    }],
      [{ text: '◀ Retour',        callback_data: 'action:panel'        }],
    ],
  };
}

function backKeyboard() {
  return { inline_keyboard: [[{ text: '◀ Retour au panel', callback_data: 'action:panel' }]] };
}

function searchNavKeyboard(page, maxPage, query, deep) {
  const d = deep ? '1' : '0';
  const q = query.slice(0, 40);
  const navRow = [];
  if (page > 1)       navRow.push({ text: '◀', callback_data: 'sr:' + d + ':' + (page-1) + ':' + q });
  navRow.push(          { text: page+'/'+maxPage, callback_data: 'sr_noop' });
  if (page < maxPage) navRow.push({ text: '▶', callback_data: 'sr:' + d + ':' + (page+1) + ':' + q });
  return {
    inline_keyboard: [
      navRow,
      [
        { text: '📥 Télécharger', callback_data: 'sdl_menu:' + page + ':' + q },
        { text: '◀ Retour', callback_data: 'action:panel' },
      ],
    ],
  };
}

// ── Cache search par userId ───────────────────────────────────────────────────
const searchCache = new Map(); // userId → { results, total, query, deep }

// ── État conversationnel (attente d'une réponse) ──────────────────────────────
const waitingFor = new Map(); // userId → { type: 'searcher'|'tool', toolKey?, toolField? }

// ── Affichage résultat search ─────────────────────────────────────────────────
function tryParseJSON(str) {
  if (!str) return null;
  try {
    const obj = JSON.parse(typeof str === 'string' ? str : JSON.stringify(str));
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) return obj;
  } catch (_) {}
  return null;
}

function detectFieldType(key, val) {
  const s = String(val).trim();
  if (/^(\+|00)?[0-9][\d \-\.]{6,20}$/.test(s.replace(/[\s\-\.]/g,''))) {
    if (/^(\+33|0033|0[67])\d{8}$/.test(s.replace(/[\s\-\.]/g,'')) || /^\+[1-9]\d{6,14}$/.test(s.replace(/\s/g,''))) return 'phone';
  }
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(s)) return 'ip';
  if (/^[^\@\s]+@[^\@\s]+\.[^\@\s]+$/.test(s)) return 'email';
  if (/^[A-Z]{2}[-\s]?[0-9]{3}[-\s]?[A-Z]{2}$/i.test(s)) return 'voiture';
  if (/^[0-9a-f]{32}$/i.test(s)) return 'hash';
  if (/^[0-9a-f]{40}$/i.test(s)) return 'hash';
  if (/^[0-9a-f]{64}$/i.test(s)) return 'hash';
  return null;
}

function parseVexbaseResult(res) {
  const JSON_FIELDS = ['raw','preview','fields','data','record','entry'];
  let merged = {};
  for (const field of JSON_FIELDS) {
    if (res[field]) {
      const parsed = tryParseJSON(res[field]);
      if (parsed) Object.assign(merged, parsed);
      else if (field === 'raw' || field === 'preview') merged._raw_string = String(res[field]);
    }
  }
  const META = new Set(['source','shard','preview','raw','fields','data','record','entry','identity','credentials','_id','cachedAt']);
  for (const [k,v] of Object.entries(res)) { if (!META.has(k)) merged[k] = v; }
  if (res.identity)    Object.assign(merged, res.identity);
  if (res.credentials) Object.assign(merged, res.credentials);
  if (res.leakDate || res.leak_date || res.leakdate)
    merged.leakDate = res.leakDate || res.leak_date || res.leakdate;
  return merged;
}

const TG_CODE = new Set([
  'email','mail','email_address','phone','telephone','phone_number','mobile','portable','tel','tel2',
  'ip','ip_address','last_ip','password','pass','mot_de_passe','hash','password_hash','hashed_password',
  'iban','bic','zip','postal_code','code_postal','username','login','user','pseudo',
  'code_naf','naf','plaque','immatriculation',
]);

// label + icon pour chaque champ connu
const TG_FIELD_MAP = {
  email:['📧','Email'], mail:['📧','Email'], email_address:['📧','Email'],
  nom:['👤','Nom'], name:['👤','Nom'], last_name:['👤','Nom'], surname:['👤','Nom'],
  prenom:['👤','Prénom'], first_name:['👤','Prénom'],
  full_name:['👤','Nom complet'],
  civilite:['🪪','Civilité'], civility:['🪪','Civilité'], gender:['🪪','Genre'],
  phone:['📞','Téléphone'], telephone:['📞','Téléphone'], phone_number:['📞','Téléphone'],
  mobile:['📞','Mobile'], portable:['📞','Portable'], tel:['📞','Téléphone'], tel2:['📞','Tél. 2'],
  adresse:['🏠','Adresse'], address:['🏠','Adresse'], street:['🏠','Rue'],
  ville:['🏙️','Ville'], city:['🏙️','Ville'], commune:['🏙️','Commune'],
  zip:['📮','Code postal'], postal_code:['📮','Code postal'], code_postal:['📮','Code postal'],
  birthday:['🎂','Naissance'], birth_date:['🎂','Naissance'],
  date_naissance:['🎂','Naissance'], naissance:['🎂','Naissance'], age:['🎂','Âge'],
  password:['🔑','Password'], pass:['🔑','Password'], mot_de_passe:['🔑','Password'],
  hash:['🔒','Hash'], password_hash:['🔒','Hash'], hashed_password:['🔒','Hash'],
  ip:['🌐','IP'], ip_address:['🌐','IP'], last_ip:['🌐','Dernière IP'],
  username:['👾','Pseudo'], login:['👾','Login'], user:['👾','Pseudo'], pseudo:['👾','Pseudo'],
  entreprise:['🏢','Entreprise'], company:['🏢','Entreprise'],
  iban:['💳','IBAN'], bank:['🏦','Banque'], banque:['🏦','Banque'], bic:['🏦','BIC'],
  activite:['⚙️','Activité'], activity:['⚙️','Activité'], code_naf:['⚙️','Code NAF'],
  creation:['📅','Création'], effectif:['👥','Effectif'],
  country:['🌍','Pays'], pays:['🌍','Pays'],
  departement:['🌍','Département'], region:['🌍','Région'],
  nationalite:['🌍','Nationalité'], nationality:['🌍','Nationalité'],
  plaque:['🚗','Plaque'], immatriculation:['🚗','Immatriculation'],
  leakdate:['📅','Leak date'], leak_date:['📅','Leak date'], leakDate:['📅','Leak date'],
};

function tgFieldVal(key, val) {
  const s = String(val).slice(0, 100);
  return TG_CODE.has(key.toLowerCase()) ? code(s) : esc(s);
}

function buildSearchPage(query, results, page, total) {
  const maxPage = Math.min(25, results.length);
  const res     = results[page - 1];
  const lines   = [
    bold('Recherche — ' + esc(query)),
    esc(total + ' résultat' + (total>1?'s':'') + (maxPage>1 ? '  ·  page ' + page + '/' + maxPage : '')),
    hr(),
  ];

  if (!res) { lines.push(esc('Aucun résultat.')); return lines.join('\n'); }

  const meta = [];
  if (res.source) meta.push(esc(res.source));
  if (res.shard)  meta.push(esc(res.shard));
  if (meta.length) lines.push(meta.join(' · '));

  const merged    = parseVexbaseResult(res);
  const displayed = new Set(['_id','cachedAt','_raw_string']);

  // Champs connus — utiliser le label du map (pas rawKey) pour éviter doublons
  for (const [rawKey, val] of Object.entries(merged)) {
    if (displayed.has(rawKey) || val==null || val==='') continue;
    const cfg = TG_FIELD_MAP[rawKey.toLowerCase()];
    if (cfg) {
      const [icon, label] = cfg;
      lines.push(icon + ' ' + bold(label) + '  ' + tgFieldVal(rawKey, val));
      displayed.add(rawKey);
    }
  }

  // Détection auto pour champs inconnus
  const autoLines = [];
  const restLines = [];
  for (const [rawKey, val] of Object.entries(merged)) {
    if (displayed.has(rawKey) || val==null || val==='') continue;
    if (TG_FIELD_MAP[rawKey.toLowerCase()]) continue;
    if (typeof val === 'object') { restLines.push(esc(rawKey) + ' ' + esc(JSON.stringify(val).slice(0,80))); displayed.add(rawKey); continue; }
    const det = detectFieldType(rawKey, val);
    if (det && TG_FIELD_MAP[det]) {
      const [icon, label] = TG_FIELD_MAP[det];
      autoLines.push(icon + ' ' + bold(label) + '  ' + tgFieldVal(det, val));
    } else {
      restLines.push(esc(rawKey) + ' ' + tgFieldVal(rawKey, val));
    }
    displayed.add(rawKey);
  }
  if (autoLines.length) lines.push(...autoLines);
  if (restLines.length) { lines.push(hr()); lines.push(esc('Reste')); lines.push(...restLines.map(l => '  ' + l)); }

  if (merged._raw_string) {
    lines.push(hr());
    lines.push(esc('Données brutes'));
    lines.push(esc(merged._raw_string.slice(0, 600)));
  }

  return lines.join('\n');
}

// Keyboard téléchargement search Telegram
function searchDLKeyboard(page, query) {
  const q = query.slice(0, 40);
  return {
    inline_keyboard: [
      [
        { text: '📄 JSON',  callback_data: 'sdl:json:' + page + ':' + q },
        { text: '📊 CSV',   callback_data: 'sdl:csv:'  + page + ':' + q },
        { text: '📝 TXT',   callback_data: 'sdl:txt:'  + page + ':' + q },
      ],
      [
        { text: '🗄️ SQL',  callback_data: 'sdl:sql:'  + page + ':' + q },
        { text: '📋 XML',  callback_data: 'sdl:xml:'  + page + ':' + q },
      ],
      [{ text: '◀ Retour', callback_data: 'action:panel' }],
    ],
  };
}

// ── Tool descriptions ─────────────────────────────────────────────────────────
const TOOL_CFG = {
  'github':         { label: 'GitHub',       field: 'username', prompt: 'Entrez le nom d\'utilisateur GitHub :',   example: 'torvalds' },
  'analyze-ip':     { label: 'IP',           field: 'ip',       prompt: 'Entrez l\'adresse IP :',                 example: '8.8.8.8' },
  'analyze-hash':   { label: 'Hash',         field: 'hash',     prompt: 'Entrez le hash à identifier :',          example: '5f4dcc3b...' },
  'analyze-phone':  { label: 'Téléphone',    field: 'phone',    prompt: 'Entrez le numéro de téléphone :',        example: '+33612345678' },
  'analyze-gps':    { label: 'GPS',          field: 'coords',   prompt: 'Entrez les coordonnées GPS :',           example: '48.8566, 2.3522' },
  'analyze-invite': { label: 'Invitation',   field: 'url',      prompt: 'Entrez l\'URL d\'invitation :',          example: 'https://discord.gg/...' },
  'analyze-plate':  { label: 'Plaque FR',    field: 'plaque',   prompt: 'Entrez la plaque SIV :',                 example: 'AB-123-CD' },
  'analyze-ua':     { label: 'User-Agent',   field: 'ua',       prompt: 'Entrez le User-Agent :',                 example: 'Mozilla/5.0...' },
  'analyze-dns':    { label: 'DNS',          field: 'domain',   prompt: 'Entrez le domaine :',                    example: 'google.com' },
};

// ── Exécution d'un outil ──────────────────────────────────────────────────────
async function runTool(bot, chatId, toolKey, value, config) {
  try {
    let data;
    if (toolKey === 'github') {
      data = await fetchGithubProfile(value.replace(/^@/, ''), config.githubToken || null);
      const emails = data.emails ?? [];
      const lines = [
        bold('GitHub — @' + esc(value)),
        hr(),
        line('Nom',       data.name || '—'),
        line('Type',      data.accountType),
        data.location ? line('Localisation', data.location) : null,
        data.company  ? line('Entreprise',   data.company)  : null,
        data.bio      ? line('Bio',          data.bio.slice(0,100)) : null,
        '',
        line('Repos',     data.publicRepos),
        line('Stars',     data.totalStars),
        line('Followers', data.followers),
        '',
        bold('Emails OSINT'),
        ...(emails.length ? emails.map(em => '  • ' + code(em)) : ['  _Aucun email trouvé_']),
        data.topLangs?.length ? '\n' + line('Langages', data.topLangs.join(', ')) : null,
        data.blog ? line('Site', data.blog) : null,
        '',
        '🔗 ' + esc(data.htmlUrl),
      ].filter(l => l !== null).join('\n');

      const kb = { inline_keyboard: [[{ text: '🔗 Profil GitHub', url: data.htmlUrl }], [{ text: '◀ Retour', callback_data: 'action:panel' }]] };
      return send(bot, chatId, lines, { reply_markup: kb });
    }

    if (toolKey === 'analyze-ip') {
      data = await fetchIPInfo(value);
      const flag = data.countryCode && data.countryCode !== '—'
        ? String.fromCodePoint(...[...data.countryCode.toUpperCase()].map(c => 0x1F1E6 + c.charCodeAt(0) - 65)) : '';
      const lines = [
        bold('IP — ' + esc(value)),
        hr(),
        line('Pays',     flag + ' ' + data.country),
        line('Région',   data.region),
        line('Ville',    data.city),
        line('Timezone', data.timezone),
        data.lat && data.lon ? line('Coords', data.lat + ', ' + data.lon) : null,
        '',
        line('ISP',      data.isp),
        line('ASN',      data.asn),
        data.asnName !== '—' ? line('AS Name', data.asnName) : null,
        '',
        line('Proxy',    data.isProxy  ? '✅ OUI' : '❌ Non'),
        line('VPN',      data.isVPN    ? '✅ OUI' : '❌ Non'),
        line('Tor',      data.isTor    ? '✅ OUI' : '❌ Non'),
        data.reverseDns !== '—' ? line('rDNS', data.reverseDns) : null,
      ].filter(l => l !== null).join('\n');
      return send(bot, chatId, lines, { reply_markup: backKeyboard() });
    }

    if (toolKey === 'analyze-invite') {
      data = await analyzeInvite(value);
      if (data.platform === 'Discord') {
        const lines = [
          bold('Invitation Discord'),
          hr(),
          line('Serveur',  data.guildName),
          line('ID',       data.guildId),
          data.memberCount ? line('Membres',  data.memberCount.toLocaleString('fr-FR')) : null,
          data.onlineCount ? line('En ligne', data.onlineCount.toLocaleString('fr-FR')) : null,
          data.channelName ? line('Salon',    '#' + data.channelName) : null,
          data.inviterTag  ? line('Inviteur', data.inviterTag) : null,
          data.guildBoostTier ? line('Boost tier', data.guildBoostTier) : null,
          data.guildDescription ? line('Description', data.guildDescription.slice(0, 100)) : null,
        ].filter(l => l !== null).join('\n');
        const kb = {
          inline_keyboard: [
            [{ text: '🔗 Rejoindre', url: data.inviteUrl }],
            ...(data.iconUrl   ? [[{ text: '🖼️ Avatar',   url: data.iconUrl   }]] : []),
            ...(data.bannerUrl ? [[{ text: '🖼️ Bannière', url: data.bannerUrl }]] : []),
            [{ text: '◀ Retour', callback_data: 'action:panel' }],
          ],
        };
        return send(bot, chatId, lines, { reply_markup: kb });
      }
    }

    // Autres outils via API
    const cfg = TOOL_CFG[toolKey];
    data = await tool(toolKey, { [cfg.field]: value }, { config });

    const lines = [bold(cfg.label + ' — ' + esc(value)), hr()];
    function flat(obj, prefix) {
      for (const [k,v] of Object.entries(obj)) {
        if (v == null) continue;
        const key = prefix ? prefix + '.' + k : k;
        if (typeof v === 'object' && !Array.isArray(v)) flat(v, key);
        else if (Array.isArray(v)) lines.push(line(key, v.slice(0,5).join(', ')));
        else lines.push(line(key, String(v).slice(0,100)));
      }
    }
    flat(data, '');
    return send(bot, chatId, lines.join('\n'), { reply_markup: backKeyboard() });

  } catch (err) {
    return send(bot, chatId, '❌ ' + esc(err.message), { reply_markup: backKeyboard() });
  }
}

// ── Démarrage ─────────────────────────────────────────────────────────────────
function startTelegramBot(config) {
  const tgCfg = config.telegram;
  if (!tgCfg?.token || tgCfg.token === 'TON_TOKEN_TELEGRAM_ICI') {
    console.log('[TG] Bot Telegram désactivé (token manquant)');
    return null;
  }

  const bot         = new TelegramBot(tgCfg.token, { polling: true });
  const channelLink = config.panel?.telegramLink || '';

  console.log('[TG] Bot Telegram démarré');
  if (channelLink) console.log('[TG] Canal requis :', channelLink);

  // ── /start ────────────────────────────────────────────────────────────────
  bot.onText(/^\/start/, async (msg) => {
    const p = config.panel ?? {};
    await send(bot, msg.chat.id,
      bold('Bienvenue sur ' + (p.botName || 'OSINT Bot') + ' !') + '\n\n' +
      esc('Utilise la commande /panel pour accéder au bot.') + '\n\n' +
      (channelLink ? esc('Rejoins notre canal : ') + channelLink : '')
    );
  });

  // ── /panel ─────────────────────────────────────────────────────────────────
  bot.onText(/^\/panel/, async (msg) => {
    const userId = msg.from?.id;
    const chatId = msg.chat.id;

    const isMember = await isMemberOfChannel(bot, userId, channelLink);
    if (!isMember) {
      return send(bot, chatId,
        bold('Accès refusé') + '\n\nTu dois être membre du canal pour utiliser ce bot\\.\n' +
        (channelLink ? 'Rejoins : ' + esc(channelLink) : ''),
        {
          reply_markup: {
            inline_keyboard: [
              ...(channelLink ? [[{ text: '📢 Rejoindre le canal', url: channelLink }]] : []),
              [{ text: '🔄 Réessayer', callback_data: 'action:retry_access' }],
            ],
          },
        }
      );
    }

    return sendPanel(bot, chatId, config);
  });

  // ── Callback buttons ───────────────────────────────────────────────────────
  bot.on('callback_query', async (query) => {
    try {
    const userId = query.from.id;
    const chatId = query.message?.chat?.id;
    const msgId  = query.message?.message_id;
    const data   = query.data;
    if (!chatId || !data) return;

    await bot.answerCallbackQuery(query.id).catch(() => {});


    // Pas de vérif membre dans les callbacks — déjà vérifiée à /panel

    if (data === 'sr_noop') return;

    // Menu téléchargement search
    if (data.startsWith('sdl_menu:')) {
      const parts = data.split(':');
      const page  = parseInt(parts[1], 10);
      const q     = parts.slice(2).join(':');
      return edit(bot, chatId, msgId, bold('Télécharger') + '\n' + esc('Choisir le format :'), {
        reply_markup: searchDLKeyboard(page, q),
      });
    }

    // Téléchargement search — format choisi
    if (data.startsWith('sdl:')) {
      const parts  = data.split(':');
      const format = parts[1];
      const page   = parseInt(parts[2], 10);
      // parts[3+] = query (ignoré ici, on utilise searchCache)

      await bot.answerCallbackQuery(query.id, { text: 'Génération en cours...' }).catch(() => {});

      const cached = searchCache.get(userId);
      if (!cached) return send(bot, chatId, esc('Session expirée.'), { reply_markup: backKeyboard() });

      const res = cached.results[page - 1];
      if (!res)  return send(bot, chatId, esc('Pas de résultat.'), { reply_markup: backKeyboard() });

      try {
        const { convert } = require('./utils/exporters');
        const { save }    = require('./utils/_generate');
        const key         = 'search_tg_' + userId + '_p' + page;
        save(key, 'search', res);
        const { content, ext } = convert('search', format, res);
        const buf  = Buffer.from(content, 'utf8');
        const name = 'osint_search_' + Date.now() + '.' + ext;
        await bot.sendDocument(chatId, buf, {
          caption: '📥 Résultat ' + (page) + ' — ' + esc(cached.query),
        }, { filename: name, contentType: 'application/octet-stream' });
      } catch (err) {
        return send(bot, chatId, '❌ ' + esc(err.message));
      }
      return;
    }

    // Retry access
    if (data === 'action:retry_access') {
      const isMember = await isMemberOfChannel(bot, userId, channelLink);
      if (isMember) {
        return sendPanel(bot, chatId, config, msgId);
      } else {
        return edit(bot, chatId, msgId,
          bold('Toujours pas membre') + '\nRejoins le canal et réessaie\\.',
          {
            reply_markup: {
              inline_keyboard: [
                ...(channelLink ? [[{ text: '📢 Rejoindre', url: channelLink }]] : []),
                [{ text: '🔄 Réessayer', callback_data: 'action:retry_access' }],
              ],
            },
          }
        );
      }
    }

    // Info
    if (data === 'action:info') {
      try {
        const wsMs  = null; // pas dispo côté Telegram
        const start = Date.now();
        let apiMs   = null;
        try {
          const { stats } = require('./utils/apiClient');
          const res = await stats({ config });
          apiMs = res.latency;
        } catch (_) {}
        const lines = [
          bold('A propos'),
          esc('Créateur : Alzheimer — https://guns.lol/alzheimer'),
          esc('Origine : France 🇫🇷'),
          '',
          bold('Latences'),
          esc('API OSINT : ') + code(apiMs != null ? apiMs + 'ms' : '—'),
        ];
        return edit(bot, chatId, msgId, lines.join('\n'), {
          reply_markup: { inline_keyboard: [[{ text: '◀ Retour', callback_data: 'action:panel' }]] },
        });
      } catch (err) {
        return send(bot, chatId, '❌ ' + esc(err.message));
      }
    }

    // Panel
    if (data === 'action:panel') {
      waitingFor.delete(userId);
      return edit(bot, chatId, msgId, buildPanelText(config), { reply_markup: panelKeyboard() });
    }

    // Searcher
    if (data === 'action:searcher') {
      waitingFor.set(userId, { type: 'searcher', chatId, msgId });
      return edit(bot, chatId, msgId,
        bold('Searcher') + '\nEnvoie le terme à rechercher \\(email, pseudo, IP\\.\\.\\.\\)',
        { reply_markup: { inline_keyboard: [[{ text: '◀ Retour', callback_data: 'action:panel' }]] } }
      );
    }

    // Tools menu
    if (data === 'action:tools') {
      return edit(bot, chatId, msgId, bold('Outils') + '\nChoisis un outil :', { reply_markup: toolsKeyboard() });
    }

    // Tool sélectionné
    if (data.startsWith('tool:')) {
      const toolKey = data.slice(5);
      const cfg     = TOOL_CFG[toolKey];
      if (!cfg) return;
      waitingFor.set(userId, { type: 'tool', toolKey, chatId, msgId });
      return edit(bot, chatId, msgId,
        bold(cfg.label) + '\n' + esc(cfg.prompt) + '\nEx : ' + code(cfg.example),
        { reply_markup: { inline_keyboard: [[{ text: '◀ Retour', callback_data: 'action:tools' }]] } }
      );
    }

    // Pagination search
    if (data.startsWith('sr:')) {
      const parts   = data.split(':');
      const d       = parts[1];
      const pageStr = parts[2];
      const query   = parts.slice(3).join(':');
      const page    = parseInt(pageStr, 10);
      const deep    = d === '1';
      const cached  = searchCache.get(userId);
      if (!cached) {
        return edit(bot, chatId, msgId, esc('Session expirée. Relance /panel → Searcher.'), { reply_markup: backKeyboard() });
      }
      const maxPage = Math.min(25, cached.results.length);
      const newPage = Math.max(1, Math.min(maxPage, page));
      const txt = buildSearchPage(cached.query, cached.results, newPage, cached.total);
      return edit(bot, chatId, msgId, txt, { reply_markup: searchNavKeyboard(newPage, Math.min(25, cached.results.length), cached.query, deep) });
    }
    } catch (err) {
      console.error('[TG callback]', query.data, err.message);
    }
  });

  // ── Messages texte (réponses aux prompts) ──────────────────────────────────
  bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;
    const userId = msg.from?.id;
    const chatId = msg.chat.id;
    const waiting = waitingFor.get(userId);
    if (!waiting) return;

    waitingFor.delete(userId);
    const value = msg.text.trim();

    // Searcher
    if (waiting.type === 'searcher') {
      try {
        await bot.sendMessage(chatId, esc('🔍 Recherche de ') + code(value) + '\\.\\.\\.',
          { parse_mode: 'MarkdownV2' });

        const { data } = await search(value, false, { config });
        const results  = (data.results ?? []).slice(0, 25);
        const total    = data.total_results ?? results.length;

        searchCache.set(userId, { results, total, query: value, deep: false });

        if (!total) {
          return send(bot, chatId, bold('Aucun résultat') + '\nPas de résultat pour ' + code(value),
            { reply_markup: backKeyboard() });
        }

        const maxPage = Math.min(25, results.length);
        const txt     = buildSearchPage(value, results, 1, total);
        return send(bot, chatId, txt, {
          reply_markup: maxPage > 1 ? searchNavKeyboard(1, maxPage, value, false) : backKeyboard(),
        });
      } catch (err) {
        return send(bot, chatId, '❌ ' + esc(err.message), { reply_markup: backKeyboard() });
      }
    }

    // Tool
    if (waiting.type === 'tool') {
      await bot.sendMessage(chatId, esc('🔍 Analyse en cours\\.\\.\\.'), { parse_mode: 'MarkdownV2' });
      return runTool(bot, chatId, waiting.toolKey, value, config);
    }
  });

  bot.on('polling_error', err => {
    console.error('[TG] Polling error:', err.code, err.message);
    if (err.code === 'ETELEGRAM' && err.message.includes('401')) {
      console.error('[TG] TOKEN INVALIDE — vérifie config.json telegram.token');
    }
  });
  return bot;
}

module.exports = { startTelegramBot };

'use strict';

function eph(obj) { return { ...obj, flags: (obj.flags || 0) | require('discord.js').MessageFlags.IsComponentsV2 | require('discord.js').MessageFlags.Ephemeral }; }

const {
  ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
  ContainerBuilder, TextDisplayBuilder, MessageFlags,
} = require('discord.js');

const { search }      = require('../utils/apiClient');
const { logAction }   = require('../utils/logger');
const {
  buildError, buildSearchTypePicker, buildSearchPage,
  buildDeepLimitReached, e,
} = require('../utils/builders');

const txt = c => new TextDisplayBuilder().setContent(c);

const searchCache = new Map(); // userId → { query, deep, results, total }
const deepLimits  = new Map(); // userId → { count, resetAt }

function checkDeep(userId, limit) {
  const now = Date.now(), entry = deepLimits.get(userId);
  if (!entry || now > entry.resetAt) return { allowed: true, remaining: limit };
  if (entry.count >= limit) return { allowed: false, hoursLeft: ((entry.resetAt - now) / 3_600_000).toFixed(1) };
  return { allowed: true, remaining: limit - entry.count };
}

function consumeDeep(userId) {
  const now = Date.now(), entry = deepLimits.get(userId);
  if (!entry || now > entry.resetAt) deepLimits.set(userId, { count: 1, resetAt: now + 86_400_000 });
  else entry.count++;
}

// ── Searcher → type picker ────────────────────────────────────────────────────
async function handleSearchOpen(interaction, client) {
  return interaction.reply(eph(buildSearchTypePicker()));
}

// ── Type picker → modales ─────────────────────────────────────────────────────
async function handleSearchNormalOpen(interaction, client) {
  // Le check statut est déjà fait dans handleSearchButton (panel.js)
  // qui appelle handleSearchOpen → buildSearchTypePicker
  // Ici on arrive depuis le bouton search_run_normal dans le picker
  return openModal(interaction, false);
}

async function handleSearchDeepOpen(interaction, client) {
  const limit = client.config.deepSearchLimitPerDay ?? 2;
  const check = checkDeep(interaction.user.id, limit);
  if (!check.allowed) return interaction.update(buildDeepLimitReached(check.hoursLeft, limit));
  return openModal(interaction, true);
}

async function openModal(interaction, deep) {
  const modal = new ModalBuilder()
    .setCustomId(deep ? 'search_modal_deep' : 'search_modal')
    .setTitle(deep ? 'Recherche approfondie' : 'Recherche OSINT');
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('search_query').setLabel('Terme a rechercher')
        .setPlaceholder('email, pseudo, IP, telephone...').setStyle(TextInputStyle.Short)
        .setMinLength(4).setMaxLength(200).setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

// ── Soumission modal ─────────────────────────────────────────────────────────
async function handleSearchModal(interaction, client) {
  const deep  = interaction.customId === 'search_modal_deep';
  const query = interaction.fields.getTextInputValue('search_query').trim();
  if (!query) return interaction.reply(eph(buildError('Invalide', 'Terme vide.')));
  if (query.length < 4) return interaction.reply(eph(buildError('Terme trop court', 'La recherche necessite au moins **4 caracteres**\n> Vexbase impose un minimum de 4 caracteres.')));

  const limit = client.config.deepSearchLimitPerDay ?? 2;
  if (deep) {
    const check = checkDeep(interaction.user.id, limit);
    if (!check.allowed) return interaction.reply(eph(buildDeepLimitReached(check.hoursLeft, limit)));
    consumeDeep(interaction.user.id);
  }

  // IMPORTANT : deferReply immédiat — la modal doit être acquittée en < 3s
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const lE = e('loading');
    await interaction.editReply({
      components: [
        new ContainerBuilder().setAccentColor(deep ? 0xED4245 : 0x5865F2)
          .addTextDisplayComponents(txt(
            (lE ? lE + '  ' : '') +
            '**' + (deep ? 'Analyse approfondie' : 'Recherche') + '...**\n> `' + query + '`'
          )),
      ],
      flags: MessageFlags.IsComponentsV2,
    });

    const { data } = await search(query, deep, client);
    const results  = (data.results ?? []).slice(0, 25);
    const total    = data.total_results ?? results.length;

    searchCache.set(interaction.user.id, { query, deep, results, total });
    logAction(client, interaction.user, 'search', query, { Deep: deep ? 'Oui' : null, Resultats: total });
    await interaction.editReply(buildSearchPage(query, deep, results, 1, total));
  } catch (err) {
    const msg = err.response?.data?.message || err.message;
    await interaction.editReply(buildError('Erreur', msg.slice(0, 300)));
  }
}

// ── Téléchargement flux 3 étapes ────────────────────────────────────────────
// ── Pagination ────────────────────────────────────────────────────────────────
async function handleSearchPrev(interaction, client) {
  return _navigate(interaction, -1);
}

async function handleSearchNext(interaction, client) {
  return _navigate(interaction, +1);
}

async function _navigate(interaction, delta) {
  const parts = interaction.customId.split('_');
  const dFlag = parts[2], page = parseInt(parts[3], 10);
  const query = decodeURIComponent(parts.slice(4).join('_'));

  const cached = searchCache.get(interaction.user.id);
  if (!cached) return interaction.update(buildError('Session expiree', 'Relance une recherche.'));

  const newPage = Math.max(1, Math.min(25, Math.min(cached.results.length, page + delta)));
  return interaction.update(buildSearchPage(cached.query, cached.deep, cached.results, newPage, cached.total));
}

// Étape 1 : sr_dl_<page>_<queryEnc> → format picker
async function handleSearchDL(interaction, client) {
  const parts    = interaction.customId.split('_');
  const page     = parseInt(parts[2], 10);

  const cached = searchCache.get(interaction.user.id);
  if (!cached) {
    return interaction.reply(eph(buildError('Session expiree', 'Relance une recherche.')));
  }
  const res = cached.results[page - 1];
  if (!res) {
    return interaction.reply(eph(buildError('Introuvable', 'Pas de resultat a cette page.')));
  }

  const { save } = require('../utils/_generate');
  const key = 'search_' + interaction.user.id + '_p' + page;
  save(key, 'search', res);

  const { buildExportFormatPicker } = require('../utils/builders');
  return interaction.reply(eph(buildExportFormatPicker(key, 'search')));
}

// Étape 2 : search_fmt_<format>_<key> → zip picker
async function handleSearchFmt(interaction, client) {
  const raw    = interaction.customId.slice('search_fmt_'.length);
  const pivot  = raw.indexOf('_');
  const format = raw.slice(0, pivot);
  const key    = raw.slice(pivot + 1);
  const { buildExportZipPicker } = require('../utils/builders');
  return interaction.update(buildExportZipPicker(key, 'search', format));
}

// Étape 3 : search_zip_<yes|no>_<format>_<key> → generate
async function handleSearchZip(interaction, client) {
  const raw    = interaction.customId.slice('search_zip_'.length);
  const parts  = raw.split('_');
  const doZip  = parts[0] === 'yes';
  const format = parts[1];
  const key    = parts.slice(2).join('_');

  const { buildExportGenerating } = require('../utils/builders');
  await interaction.update(buildExportGenerating(key));

  const { generate } = require('../utils/_generate');
  await generate(interaction, key, 'search', format, doZip);
}

module.exports = {
  handleSearchOpen,
  handleSearchNormalOpen,
  handleSearchDeepOpen,
  handleSearchModal,
  handleSearchPrev,
  handleSearchNext,
  handleSearchDL,
  handleSearchFmt,
  handleSearchZip,
};

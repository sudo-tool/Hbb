'use strict';

const { MessageFlags, buildError, buildInfo } = require('../utils/builders');
const { openToolModal }         = require('./tools');
const { handleSearchOpen }      = require('./search');
const { stats }                 = require('../utils/apiClient');

const { checkAccess, extractSlug } = require('../utils/access');

function denyAccess(interaction, client) {
  const slug = extractSlug(client.config.requiredStatus);
  return interaction.reply({
    ...buildError('Acces restreint', 'Tu dois avoir `.gg/' + slug + '` dans ton statut Discord.'),
    ephemeral: true,
  });
}

// Menu tools (github + outils API)
async function handleToolSelect(interaction, client) {
  if (!checkAccess(interaction, client)) return denyAccess(interaction, client);
  const value = interaction.values[0];

  if (value === 'github') {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
    const modal = new ModalBuilder().setCustomId('gh_modal').setTitle('GitHub OSINT');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('gh_username').setLabel('Nom d\'utilisateur')
          .setPlaceholder('@torvalds').setStyle(TextInputStyle.Short)
          .setMinLength(1).setMaxLength(39).setRequired(true)
      )
    );
    return interaction.showModal(modal);
  }

  return openToolModal(interaction, value);
}

// Bouton Searcher
async function handleSearchButton(interaction, client) {
  if (!checkAccess(interaction, client)) return denyAccess(interaction, client);
  return handleSearchOpen(interaction, client);
}

// Bouton Info — ping WS + ping API
async function handleInfoButton(interaction, client) {
  if (!checkAccess(interaction, client)) return denyAccess(interaction, client);
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  const wsLatency = client.ws.ping;
  let apiLatency = null;
  try {
    const res = await stats(client);
    apiLatency = res.latency;
  } catch (_) {}
  return interaction.editReply(buildInfo(wsLatency, apiLatency));
}

module.exports = { handleToolSelect, handleSearchButton, handleInfoButton };

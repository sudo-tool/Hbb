'use strict';

function eph(obj) { return { ...obj, flags: (obj.flags || 0) | require('discord.js').MessageFlags.IsComponentsV2 | require('discord.js').MessageFlags.Ephemeral }; }

const {
  ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
  ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SectionBuilder,
  ThumbnailBuilder, SeparatorSpacingSize, MessageFlags, ButtonBuilder, ButtonStyle,
} = require('discord.js');

const { tool }            = require('../utils/apiClient');
const { analyzeInvite }   = require('../utils/inviteScraper');
const { buildError, e, emojiObj } = require('../utils/builders');
const { logAction }            = require('../utils/logger');

const sep = () => new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true);
const txt = c  => new TextDisplayBuilder().setContent(c);

const TOOLS = {
  'analyze-ip':     { field: 'ip',     placeholder: '8.8.8.8',              title: 'Analyse IP'          },
  'analyze-hash':   { field: 'hash',   placeholder: '5f4dcc3b5aa765d61...',  title: 'Identifier Hash'     },
  'analyze-phone':  { field: 'phone',  placeholder: '+33612345678',          title: 'Analyse Telephone'   },
  'analyze-gps':    { field: 'coords', placeholder: '48.8566, 2.3522',       title: 'Analyse GPS'         },
  'analyze-invite': { field: 'url',    placeholder: 'https://discord.gg/...', title: 'Analyse Invitation' },
  'analyze-plate':  { field: 'plaque', placeholder: 'AB-123-CD',             title: 'Analyse Plaque SIV'  },
  'analyze-ua':     { field: 'ua',     placeholder: 'Mozilla/5.0...',        title: 'Analyse User-Agent'  },
  'analyze-dns':    { field: 'domain', placeholder: 'google.com',            title: 'Lookup DNS'          },
};

async function openToolModal(interaction, toolKey) {
  const cfg = TOOLS[toolKey];
  if (!cfg) return interaction.reply(eph(buildError('Outil inconnu', toolKey)));
  const modal = new ModalBuilder().setCustomId('tool_modal_' + toolKey).setTitle(cfg.title);
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('tool_input').setLabel('Valeur')
        .setPlaceholder(cfg.placeholder).setStyle(TextInputStyle.Short)
        .setMinLength(1).setMaxLength(500).setRequired(true)
    )
  );
  await interaction.showModal(modal);
}

async function handleToolModal(interaction, client) {
  const toolKey = interaction.customId.replace('tool_modal_', '');
  const cfg     = TOOLS[toolKey];
  if (!cfg) return interaction.reply(eph(buildError('Outil inconnu', toolKey)));

  const value = interaction.fields.getTextInputValue('tool_input').trim();
  if (!value) return interaction.reply(eph(buildError('Invalide', 'Champ vide.')));

  const eLoad = e('loading');
  await interaction.reply({
    components: [
      new ContainerBuilder().setAccentColor(0x5865F2)
        .addTextDisplayComponents(txt(
          (eLoad ? eLoad + '  ' : '') + '**' + cfg.title + '...**\n> `' + value + '`'
        )),
    ],
    flags: MessageFlags.IsComponentsV2,
    ephemeral: true,
  });

  try {
    // analyze-invite : on utilise notre scraper direct (plus fiable)
    if (toolKey === 'analyze-invite') {
      const data = await analyzeInvite(value);
      saveToolResult(toolKey + '__' + encodeURIComponent(value).slice(0,40), data);
      logAction(client, interaction.user, 'tool', 'invite : ' + value, { Serveur: data.guildName || null, Membres: data.memberCount || null });
      return interaction.editReply(buildInviteResult(data));
    }

    const result = await tool(toolKey, { [cfg.field]: value }, client);
    const _cacheKey = toolKey + '__' + encodeURIComponent(value).slice(0,40);
    saveToolResult(_cacheKey, result);
    logAction(client, interaction.user, 'tool', toolKey + ' : ' + value, null);
    return interaction.editReply(buildToolResult(toolKey, value, result));
  } catch (err) {
    const msg = err.response?.data?.message || err.message;
    return interaction.editReply(buildError('Erreur', msg.slice(0, 300)));
  }
}

// ── Résultat invite Discord ────────────────────────────────────────────────────
function buildInviteResult(data) {
  const eDiscord = e('discord');
  const eOui     = e('oui');
  const eNon     = e('non');
  const eMaison  = e('maison');
  const ePhone   = e('phone');

  if (data.platform === 'Telegram') {
    const container = new ContainerBuilder().setAccentColor(0x2AABEE)
      .addTextDisplayComponents(txt(
        (e('telegram') ? e('telegram') + '  ' : '') + '**Invitation Telegram**\n\n' +
        '**Code**  `' + data.code + '`\n' +
        '**URL**   ' + data.url
      ));
    return { components: [container], flags: MessageFlags.IsComponentsV2 };
  }

  // Discord — section avec avatar du serveur
  const headerText =
    (eDiscord ? eDiscord + '  ' : '') + '**' + data.guildName + '**\n' +
    (data.guildDescription ? '*' + data.guildDescription.slice(0, 100) + '*\n' : '') +
    '`' + data.guildId + '`';

  const sectionBuilder = new SectionBuilder()
    .addTextDisplayComponents(txt(headerText));

  if (data.iconUrl) {
    sectionBuilder.setThumbnailAccessory(new ThumbnailBuilder().setURL(data.iconUrl));
  }

  const container = new ContainerBuilder()
    .setAccentColor(0x5865F2)
    .addSectionComponents(sectionBuilder)
    .addSeparatorComponents(sep());

  // Stats
  const stats = [];
  if (data.memberCount  != null) stats.push('**Membres**  `' + data.memberCount.toLocaleString('fr-FR') + '`');
  if (data.onlineCount  != null) stats.push('**En ligne** `' + data.onlineCount.toLocaleString('fr-FR')  + '`');
  if (data.channelName)          stats.push('**Salon**    `#' + data.channelName + '`');
  if (stats.length) container.addTextDisplayComponents(txt(stats.join('  ·  '))).addSeparatorComponents(sep());

  // Infos serveur
  const serverInfo = [];
  if (data.guildBoostTier)    serverInfo.push('**Boost tier**  `' + data.guildBoostTier + '`');
  if (data.guildBoosts)       serverInfo.push('**Boosts**      `' + data.guildBoosts + '`');
  const verif = ['Aucune','Faible','Moyenne','Haute','Tres haute'];
  if (data.guildVerification != null) serverInfo.push('**Verification** `' + (verif[data.guildVerification] || data.guildVerification) + '`');
  if (data.guildNSFW)         serverInfo.push('**NSFW**  ' + (eOui || 'Oui'));
  if (data.guildFeatures?.includes('VERIFIED')) serverInfo.push('**Verifie**  ' + (eOui || 'Oui'));
  if (data.guildFeatures?.includes('PARTNERED')) serverInfo.push('**Partenaire**  ' + (eOui || 'Oui'));
  if (serverInfo.length) container.addTextDisplayComponents(txt(serverInfo.join('  ·  '))).addSeparatorComponents(sep());

  // Inviteur + expiration
  const inviteInfo = [];
  if (data.inviterTag)  inviteInfo.push('**Inviteur**    `' + data.inviterTag + '`' + (data.inviterId ? '  (`' + data.inviterId + '`)' : ''));
  if (data.uses != null && data.maxUses) inviteInfo.push('**Utilisations** `' + data.uses + '/' + data.maxUses + '`');
  if (data.expiresAt)   inviteInfo.push('**Expire le**   <t:' + Math.floor(new Date(data.expiresAt).getTime() / 1000) + ':f>');
  if (inviteInfo.length) container.addTextDisplayComponents(txt(inviteInfo.join('\n'))).addSeparatorComponents(sep());

  container.addTextDisplayComponents(txt('-# <t:' + Math.floor(Date.now() / 1000) + ':R>'));

  // Boutons : Rejoindre + Avatar + Bannière + Splash
  const btns = [
    new ButtonBuilder().setURL('https://discord.gg/' + data.code).setLabel('Rejoindre').setStyle(ButtonStyle.Link),
  ];
  if (data.iconUrl)   btns.push(new ButtonBuilder().setURL(data.iconUrl).setLabel('Avatar').setStyle(ButtonStyle.Link));
  if (data.bannerUrl) btns.push(new ButtonBuilder().setURL(data.bannerUrl).setLabel('Banniere').setStyle(ButtonStyle.Link));
  if (data.splashUrl) btns.push(new ButtonBuilder().setURL(data.splashUrl).setLabel('Splash').setStyle(ButtonStyle.Link));

  // Boutons dans le container — max 5 par ActionRow
  while (btns.length) {
    container.addActionRowComponents(new ActionRowBuilder().addComponents(btns.splice(0, 5)));
  }

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

// ── Résultat autres outils ─────────────────────────────────────────────────────
function buildToolResult(toolKey, input, data) {
  const COLORS = {
    'analyze-ip': 0x00D4FF, 'analyze-hash': 0xFEE75C, 'analyze-phone': 0x57F287,
    'analyze-gps': 0xE67E22, 'analyze-plate': 0xED4245,
    'analyze-ua': 0x9B59B6, 'analyze-dns': 0x2ECC71,
  };
  const color  = COLORS[toolKey] ?? 0x5865F2;
  const cfg    = TOOLS[toolKey];

  const ePhone   = e('phone');
  const eIp      = e('ip');
  const eMaison  = e('maison');
  const eVoiture = e('voiture');
  const eHash    = e('hash');
  const eUa      = e('useragent');
  const eDns     = e('dns');
  const eOui     = e('oui');
  const eNon     = e('non');

  const lines = [];

  switch (toolKey) {
    case 'analyze-ip': {
      // Format API : { ip, type, isPrivate, riskScore, isVpn, location:{countryCode,country,region,city,zip,latitude,longitude}, isp, org, asn, ... }
      const loc = data.location ?? {};
      const flag = loc.countryCode
        ? String.fromCodePoint(...[...loc.countryCode.toUpperCase()].map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65))
        : '';
      lines.push((eIp ? eIp + ' ' : '') + '**IP**           `' + (data.ip || input) + '`');
      lines.push('**Type**         ' + (data.type || '—'));
      lines.push('**Privee**       ' + (data.isPrivate ? (eOui || 'Oui') : (eNon || 'Non')));
      if (data.isVpn)      lines.push('**VPN**          ' + (eOui || 'Oui'));
      if (data.riskScore != null) lines.push('**Risk Score**   `' + data.riskScore + '/100`');
      if (loc.country)     lines.push('**Pays**         ' + flag + ' ' + loc.country);
      if (loc.region)      lines.push('**Region**       ' + loc.region);
      if (loc.city)        lines.push('**Ville**        ' + loc.city);
      if (loc.zip)         lines.push('**Code postal**  `' + loc.zip + '`');
      if (loc.latitude && loc.longitude) lines.push('**Coords**       `' + loc.latitude + ', ' + loc.longitude + '`');
      if (data.isp)        lines.push('**ISP**          ' + data.isp);
      if (data.org)        lines.push('**Org**          ' + data.org);
      if (data.asn)        lines.push('**ASN**          `' + data.asn + '`');
      if (data.timezone)   lines.push('**Timezone**     ' + data.timezone);
      if (data.hostname)   lines.push('**Hostname**     `' + data.hostname + '`');
      // Champs supplémentaires non parsés
      const knownKeys = new Set(['ip','type','isPrivate','isVpn','riskScore','location','isp','org','asn','timezone','hostname','message']);
      for (const [k,v] of Object.entries(data)) {
        if (knownKeys.has(k) || v == null || typeof v === 'object') continue;
        lines.push('**' + k + '**  `' + String(v).slice(0,80) + '`');
      }
      break;
    }
    case 'analyze-hash':
      lines.push((eHash ? eHash + ' ' : '') + '**Hash**   `' + data.hash + '`');
      lines.push('**Types**  ' + ((data.possibleTypes ?? []).join(', ') || '—'));
      break;
    case 'analyze-phone':
      lines.push((ePhone ? ePhone + ' ' : '') + '**Tel.**        `' + data.phone + '`');
      lines.push('**Pays**        ' + data.country);
      lines.push('**Type**        ' + data.type);
      lines.push('**Operateur**   ' + data.provider);
      break;
    case 'analyze-gps':
      lines.push((eMaison ? eMaison + ' ' : '') + '**Format**    ' + data.format);
      lines.push('**Latitude**  `' + data.latitude + '`');
      lines.push('**Longitude** `' + data.longitude + '`');
      if (data.mapsUrl) lines.push('**Carte**     [Ouvrir](' + data.mapsUrl + ')');
      break;
    case 'analyze-plate':
      lines.push((eVoiture ? eVoiture + ' ' : '') + '**Plaque**   `' + data.plaque + '`');
      lines.push('**Valide**   ' + (data.formatValide ? (eOui || 'Oui') : (eNon || 'Non')));
      lines.push('**Annee**    ' + (data.anneeApproximative || '—'));
      break;
    case 'analyze-ua':
      lines.push((eUa ? eUa + ' ' : '') + '**Navigateur** ' + (data.browser || '—'));
      lines.push('**OS**         ' + (data.os     || '—'));
      lines.push('**Device**     ' + (data.device || '—'));
      break;
    case 'analyze-dns': {
      lines.push((eDns ? eDns + ' ' : '') + '**Domaine** `' + data.domain + '`');
      const rec = data.records ?? {};
      if (rec.a?.length)    lines.push('\n**A**\n'   + rec.a.slice(0,5).map(x => '`' + x + '`').join('  '));
      if (rec.mx?.length)   lines.push('\n**MX**\n'  + rec.mx.slice(0,5).map(x => '`' + x + '`').join('\n'));
      if (rec.ns?.length)   lines.push('\n**NS**\n'  + rec.ns.slice(0,5).map(x => '`' + x + '`').join('\n'));
      if (rec.txt?.length)  lines.push('\n**TXT**\n' + rec.txt.slice(0,3).map(x => '`' + x.slice(0,80) + '`').join('\n'));
      if (rec.aaaa?.length) lines.push('\n**AAAA**\n'+ rec.aaaa.slice(0,3).map(x => '`' + x + '`').join('  '));
      break;
    }
    default:
      lines.push('```json\n' + JSON.stringify(data, null, 2).slice(0, 600) + '\n```');
  }

  const container = new ContainerBuilder().setAccentColor(color)
    .addTextDisplayComponents(txt('**' + cfg.title + '** — `' + input + '`'))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt(lines.join('\n')))
    .addSeparatorComponents(sep())
    .addTextDisplayComponents(txt('-# <t:' + Math.floor(Date.now() / 1000) + ':R>'));

  // Bouton télécharger dans le container
  const { emojiObj } = require('../utils/builders');
  const dlBtn = new ButtonBuilder()
    .setCustomId('tool_dl_' + toolKey + '_' + encodeURIComponent(input).slice(0,40))
    .setLabel('Telecharger').setStyle(ButtonStyle.Secondary);
  const dlObj = emojiObj('download'); if (dlObj) dlBtn.setEmoji(dlObj);
  container.addActionRowComponents(new ActionRowBuilder().addComponents(dlBtn));

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

module.exports = { openToolModal, handleToolModal, TOOLS };

// ── Cache résultats outils ────────────────────────────────────────────────────
const toolResultCache = new Map(); // cacheKey → data

function saveToolResult(cacheKey, data) {
  toolResultCache.set(cacheKey, data);
}

function getToolResult(cacheKey) {
  return toolResultCache.get(cacheKey) ?? null;
}

// ── Flux téléchargement 3 étapes ─────────────────────────────────────────────
// Étape 1 : clic bouton Telecharger → choisir format
async function handleToolDL(interaction, client) {
  // customId = tool_dl_<toolKey>_<inputEnc>
  const raw      = interaction.customId.slice('tool_dl_'.length);
  const pivot    = raw.indexOf('_');
  const toolKey  = raw.slice(0, pivot);
  const inputEnc = raw.slice(pivot + 1);

  const { buildExportFormatPicker } = require('../utils/builders');
  const cacheKey = toolKey + '__' + inputEnc;
  return interaction.reply({
    ...buildExportFormatPicker(cacheKey, 'tool'),
    ephemeral: true,
  });
}

// Étape 2 : format choisi → choisir zip
async function handleToolFmt(interaction, client) {
  // customId = tool_fmt_<format>_<cacheKey>
  const raw      = interaction.customId.slice('tool_fmt_'.length);
  const pivot    = raw.indexOf('_');
  const format   = raw.slice(0, pivot);
  const cacheKey = raw.slice(pivot + 1);
  const { buildExportZipPicker } = require('../utils/builders');
  return interaction.update(buildExportZipPicker(cacheKey, 'tool', format));
}

// Étape 3 : zip choisi → générer
async function handleToolZip(interaction, client) {
  // customId = tool_zip_<yes|no>_<format>_<cacheKey>
  const raw      = interaction.customId.slice('tool_zip_'.length);
  const parts    = raw.split('_');
  const doZip    = parts[0] === 'yes';
  const format   = parts[1];
  const cacheKey = parts.slice(2).join('_');

  const data = getToolResult(cacheKey);
  if (!data) {
    const { buildError } = require('../utils/builders');
    return interaction.update(buildError('Session expiree', 'Relance l\'outil.'));
  }

  const { buildExportGenerating } = require('../utils/builders');
  await interaction.update(buildExportGenerating(cacheKey));

  const { generate, save } = require('../utils/_generate');
  const key = 'tool_' + interaction.user.id + '_' + Date.now();
  save(key, 'tool', data);
  await generate(interaction, key, 'tool', format, doZip);
}

module.exports.saveToolResult  = saveToolResult;
module.exports.handleToolDL    = handleToolDL;
module.exports.handleToolFmt   = handleToolFmt;
module.exports.handleToolZip   = handleToolZip;

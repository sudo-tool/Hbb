'use strict';

function eph(obj) { return { ...obj, flags: (obj.flags || 0) | require('discord.js').MessageFlags.IsComponentsV2 | require('discord.js').MessageFlags.Ephemeral }; }

const { fetchGithubProfile }                     = require('../utils/githubScraper');
const { buildGithubResult, buildGithubDetails,
        buildLoading, buildError,
        buildExportFormatPicker, buildExportZipPicker,
        buildExportGenerating }                  = require('../utils/builders');
const { logAction }                              = require('../utils/logger');
const { generate, save }                         = require('../utils/_generate');

async function handleGithubModal(interaction, client) {
  const username = interaction.fields.getTextInputValue('gh_username').replace(/^@/, '').trim();
  if (!username) return interaction.reply(eph(buildError('Invalide', 'Username vide.')));
  await interaction.reply(eph(buildLoading(username, 'gh')));
  await _lookup(interaction, client, username);
}

async function handleGithubButton(interaction, client) {
  const id = interaction.customId;

  if (id.startsWith('gh_refresh_')) {
    const u = id.slice('gh_refresh_'.length);
    await interaction.update(buildLoading(u, 'gh'));
    return _lookup(interaction, client, u);
  }
  if (id.startsWith('gh_more_')) {
    const u = id.slice('gh_more_'.length);
    return _showDetails(interaction, u);
  }
  if (id.startsWith('gh_dl_')) {
    return interaction.update(buildExportFormatPicker(id.slice('gh_dl_'.length), 'gh'));
  }
  if (id.startsWith('gh_fmt_')) {
    const rest  = id.slice('gh_fmt_'.length);
    const pivot = rest.indexOf('_');
    return interaction.update(buildExportZipPicker(rest.slice(pivot+1), 'gh', rest.slice(0, pivot)));
  }
  if (id.startsWith('gh_zip_')) {
    const rest = id.slice('gh_zip_'.length);
    const [flag, fmt, ...u] = rest.split('_');
    const username = u.join('_');
    await interaction.update(buildExportGenerating(username));
    return generate(interaction, username, 'gh', fmt, flag === 'yes');
  }
}

async function _lookup(interaction, client, username) {
  try {
    const token = client.config.githubToken || null;
    const data  = await fetchGithubProfile(username, token);
    save(username, 'gh', data);
    await interaction.editReply(buildGithubResult(data));
    logAction(client, interaction.user, 'github', username, {
      Repos: String(data.publicRepos),
      Stars: String(data.totalStars),
      Emails: data.emails?.join(', ') || null,
      Localisation: data.location || null,
      Entreprise: data.company || null,
    });
  } catch (err) {
    await interaction.editReply(buildError('Erreur', err.message.slice(0, 300))).catch(() => {});
  }
}

async function _showDetails(interaction, username) {
  const fs   = require('fs');
  const path = require('path');
  const DATA_DIR = path.join(__dirname, '../../data');
  try {
    const data = JSON.parse(require('fs').readFileSync(path.join(DATA_DIR, 'gh_' + username + '.json'), 'utf8'));
    return interaction.update(buildGithubDetails(data));
  } catch {
    return interaction.update(buildError('Pas de donnees', 'Relance une recherche.'));
  }
}

module.exports = { handleGithubModal, handleGithubButton };

'use strict';

function eph(obj) { return { ...obj, flags: (obj.flags || 0) | require('discord.js').MessageFlags.IsComponentsV2 | require('discord.js').MessageFlags.Ephemeral }; }

const { fetchIPInfo }                            = require('../utils/ipScraper');
const { buildIPResult, buildLoading, buildError,
        buildExportFormatPicker, buildExportZipPicker,
        buildExportGenerating }                  = require('../utils/builders');
const { logAction }                              = require('../utils/logger');
const { generate, save }                         = require('../utils/_generate');

async function handleIPModal(interaction, client) {
  const ip = interaction.fields.getTextInputValue('ip_input').trim();
  if (!ip) return interaction.reply(eph(buildError('Invalide', 'Adresse IP vide.')));
  await interaction.reply(eph(buildLoading(ip, 'ip')));
  await _lookup(interaction, client, ip);
}

async function handleIPButton(interaction, client) {
  const id = interaction.customId;

  if (id.startsWith('ip_refresh_')) {
    const ip = id.slice('ip_refresh_'.length);
    await interaction.update(buildLoading(ip, 'ip'));
    return _lookup(interaction, client, ip);
  }
  if (id.startsWith('ip_dl_')) {
    return interaction.update(buildExportFormatPicker(id.slice('ip_dl_'.length), 'ip'));
  }
  if (id.startsWith('ip_fmt_')) {
    const rest  = id.slice('ip_fmt_'.length);
    const pivot = rest.indexOf('_');
    return interaction.update(buildExportZipPicker(rest.slice(pivot + 1), 'ip', rest.slice(0, pivot)));
  }
  if (id.startsWith('ip_zip_')) {
    const rest = id.slice('ip_zip_'.length);
    const [flag, fmt, ...k] = rest.split('_');
    const key = k.join('_');
    await interaction.update(buildExportGenerating(key));
    return generate(interaction, key, 'ip', fmt, flag === 'yes');
  }
}

async function _lookup(interaction, client, ip) {
  try {
    const data = await fetchIPInfo(ip);
    const key  = ip.replace(/[:.]/g, '_');
    save(key, 'ip', data);
    await interaction.editReply(buildIPResult(data));
    logAction(client, interaction.user, 'ip', ip, {
      Pays:    data.country,
      Ville:   data.city,
      ISP:     data.isp,
      ASN:     data.asn,
      Proxy:   data.isProxy ? 'Oui' : null,
      VPN:     data.isVPN   ? 'Oui' : null,
    });
  } catch (err) {
    await interaction.editReply(buildError('Erreur', err.message.slice(0, 300))).catch(() => {});
  }
}

module.exports = { handleIPModal, handleIPButton };

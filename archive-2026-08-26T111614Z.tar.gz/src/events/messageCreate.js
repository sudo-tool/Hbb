'use strict';

const { buildError } = require('../utils/builders');

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;
    const { prefix, adminIds } = client.config;
    if (!message.content.startsWith(prefix)) return;

    const args    = message.content.slice(prefix.length).trim().split(/\s+/);
    const cmdName = args.shift().toLowerCase();
    const command = client.commands.get(cmdName);
    if (!command) return;

    if (command.adminOnly && !adminIds.includes(message.author.id)) {
      return message.reply(buildError('Acces refuse', 'Commande reservee aux admins.'));
    }

    try {
      await command.execute(message, args, client);
    } catch (err) {
      console.error('[ERR]', cmdName, err.message);
      message.reply(buildError('Erreur', err.message.slice(0, 200)));
    }
  },
};

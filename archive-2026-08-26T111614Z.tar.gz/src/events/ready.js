'use strict';

const { ActivityType } = require('discord.js');
const { loadEmojis }   = require('../utils/emojiManager');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    const { botStatus } = client.config;
    client.user.setPresence({
      activities: [{ name: botStatus.text, type: ActivityType.Streaming, url: botStatus.url }],
      status: 'online',
    });
    await loadEmojis(client);
    console.log('[BOT] Online :', client.user.tag);
  },
};

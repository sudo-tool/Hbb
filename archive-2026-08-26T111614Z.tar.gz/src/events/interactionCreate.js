'use strict';

const { MessageFlags } = require('discord.js');
const { checkAccess } = require('../utils/access');

const { handleToolSelect, handleSearchButton, handleInfoButton } = require('../modules/panel');
const { handleGithubModal, handleGithubButton }                  = require('../modules/github');
const { handleToolModal, handleToolDL, handleToolFmt, handleToolZip } = require('../modules/tools');
const {
  handleSearchOpen, handleSearchNormalOpen, handleSearchDeepOpen,
  handleSearchModal, handleSearchPrev, handleSearchNext,
  handleSearchDL, handleSearchFmt, handleSearchZip,
} = require('../modules/search');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      // ── Menus ─────────────────────────────────────────────────────────────
      if (interaction.isStringSelectMenu() && interaction.customId === 'tools_select') {
        return await handleToolSelect(interaction, client);
      }

      // ── Boutons ───────────────────────────────────────────────────────────
      if (interaction.isButton()) {
        const id = interaction.customId;

        // Panel
        if (id === 'search_open')            return await handleSearchOpen(interaction, client);
        if (id === 'panel_info')             return await handleInfoButton(interaction, client);

        // Search type picker
        if (id === 'search_run_normal')      return await handleSearchNormalOpen(interaction);
        if (id === 'search_run_deep')        return await handleSearchDeepOpen(interaction, client);

        // Search pagination
        if (id.startsWith('sr_prev_'))       return await handleSearchPrev(interaction, client);
        if (id.startsWith('sr_next_'))       return await handleSearchNext(interaction, client);
        if (id === 'sr_noop')                return interaction.deferUpdate().catch(() => {});

        // Search téléchargement flux 3 étapes
        if (id.startsWith('sr_dl_'))         return await handleSearchDL(interaction, client);
        if (id.startsWith('search_fmt_'))    return await handleSearchFmt(interaction, client);
        if (id.startsWith('search_zip_'))    return await handleSearchZip(interaction, client);

        // Tool téléchargement flux 3 étapes
        if (id.startsWith('tool_dl_'))       return await handleToolDL(interaction, client);
        if (id.startsWith('tool_fmt_'))      return await handleToolFmt(interaction, client);
        if (id.startsWith('tool_zip_'))      return await handleToolZip(interaction, client);

        // GitHub
        if (id.startsWith('gh_'))            return await handleGithubButton(interaction, client);
      }

      // ── Modales ───────────────────────────────────────────────────────────
      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'gh_modal')             return await handleGithubModal(interaction, client);
        if (interaction.customId.startsWith('tool_modal_'))  return await handleToolModal(interaction, client);
        if (interaction.customId === 'search_modal' ||
            interaction.customId === 'search_modal_deep') {
          if (!checkAccess(interaction, client)) {
            { const e = require('../utils/builders').buildError('Acces restreint', 'Tu dois avoir le statut requis.'); return interaction.reply({ ...e, flags: e.flags | MessageFlags.Ephemeral }); }
          }
          return await handleSearchModal(interaction, client);
        }
      }
    } catch (err) {
      console.error('[INTERACTION]', err.message);
      const msg = { content: 'Une erreur est survenue.', flags: MessageFlags.Ephemeral };
      if (interaction.replied || interaction.deferred) interaction.followUp(msg).catch(() => {});
      else interaction.reply(msg).catch(() => {});
    }
  },
};
